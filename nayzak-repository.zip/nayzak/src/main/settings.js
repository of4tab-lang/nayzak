'use strict';

const { app } = require('electron');
const fs = require('node:fs');
const path = require('node:path');

const DEFAULT_SETTINGS = {
  version: 1,
  hotkeys: {
    toggle: 'F8',
    panic: 'F9',
  },
  preferences: {
    tray: true,
    autoLaunch: false,
    trayHintShown: false,
  },
  window: null,
  ui: null,
};

function clone(value) {
  return JSON.parse(JSON.stringify(value));
}

function boundedNumber(value, fallback, min, max) {
  const number = Number(value);
  if (!Number.isFinite(number)) return fallback;
  return Math.min(max, Math.max(min, Math.round(number)));
}

class SettingsStore {
  constructor() {
    this.file = path.join(app.getPath('userData'), 'nayzak-settings.json');
    this.data = this.#load();
    this.saveTimer = null;
  }

  #load() {
    const defaults = clone(DEFAULT_SETTINGS);
    try {
      if (!fs.existsSync(this.file)) return defaults;
      const parsed = JSON.parse(fs.readFileSync(this.file, 'utf8'));
      if (!parsed || typeof parsed !== 'object' || Array.isArray(parsed)) return defaults;

      const hotkeys = parsed.hotkeys && typeof parsed.hotkeys === 'object' ? parsed.hotkeys : {};
      const preferences =
        parsed.preferences && typeof parsed.preferences === 'object' ? parsed.preferences : {};

      return {
        ...defaults,
        version: 1,
        hotkeys: {
          toggle:
            typeof hotkeys.toggle === 'string' && hotkeys.toggle.length <= 80
              ? hotkeys.toggle
              : defaults.hotkeys.toggle,
          panic:
            typeof hotkeys.panic === 'string' && hotkeys.panic.length <= 80
              ? hotkeys.panic
              : defaults.hotkeys.panic,
        },
        preferences: {
          tray: typeof preferences.tray === 'boolean' ? preferences.tray : defaults.preferences.tray,
          autoLaunch:
            typeof preferences.autoLaunch === 'boolean'
              ? preferences.autoLaunch
              : defaults.preferences.autoLaunch,
          trayHintShown:
            typeof preferences.trayHintShown === 'boolean'
              ? preferences.trayHintShown
              : defaults.preferences.trayHintShown,
        },
        window:
          parsed.window && typeof parsed.window === 'object' && !Array.isArray(parsed.window)
            ? {
                width: boundedNumber(parsed.window.width, 1180, 1000, 4000),
                height: boundedNumber(parsed.window.height, 800, 700, 3000),
                x: Number.isFinite(Number(parsed.window.x)) ? Math.round(Number(parsed.window.x)) : null,
                y: Number.isFinite(Number(parsed.window.y)) ? Math.round(Number(parsed.window.y)) : null,
                maximized: Boolean(parsed.window.maximized),
              }
            : null,
        ui: parsed.ui && typeof parsed.ui === 'object' ? parsed.ui : null,
      };
    } catch (error) {
      try {
        if (fs.existsSync(this.file)) {
          fs.renameSync(this.file, `${this.file}.corrupt-${Date.now()}`);
        }
      } catch {
        // Ignore backup failures and continue with defaults.
      }
      return defaults;
    }
  }

  get all() {
    return this.data;
  }

  get hotkeys() {
    return { ...this.data.hotkeys };
  }

  get preferences() {
    return { ...this.data.preferences };
  }

  get windowState() {
    return this.data.window ? { ...this.data.window } : null;
  }

  get ui() {
    return this.data.ui;
  }

  setHotkeys(hotkeys) {
    if (!hotkeys || typeof hotkeys !== 'object') return;
    if (typeof hotkeys.toggle === 'string' && hotkeys.toggle.length <= 80) {
      this.data.hotkeys.toggle = hotkeys.toggle;
    }
    if (typeof hotkeys.panic === 'string' && hotkeys.panic.length <= 80) {
      this.data.hotkeys.panic = hotkeys.panic;
    }
    this.save();
  }

  setPreferences(patch) {
    if (!patch || typeof patch !== 'object') return;
    for (const key of ['tray', 'autoLaunch', 'trayHintShown']) {
      if (typeof patch[key] === 'boolean') this.data.preferences[key] = patch[key];
    }
    this.save();
  }

  setWindowState(state) {
    if (!state || typeof state !== 'object') return;
    this.data.window = {
      width: boundedNumber(state.width, 1180, 1000, 4000),
      height: boundedNumber(state.height, 800, 700, 3000),
      x: Number.isFinite(Number(state.x)) ? Math.round(Number(state.x)) : null,
      y: Number.isFinite(Number(state.y)) ? Math.round(Number(state.y)) : null,
      maximized: Boolean(state.maximized),
    };
    this.save();
  }

  setUi(ui) {
    if (!ui || typeof ui !== 'object' || Array.isArray(ui)) return;
    const serialized = JSON.stringify(ui);
    if (serialized.length > 2_000_000) return;
    this.data.ui = JSON.parse(serialized);
    this.save();
  }

  save() {
    // The file is tiny; an atomic synchronous write keeps updates predictable.
    try {
      fs.mkdirSync(path.dirname(this.file), { recursive: true });
      const temporary = `${this.file}.tmp`;
      fs.writeFileSync(temporary, JSON.stringify(this.data, null, 2), 'utf8');
      fs.renameSync(temporary, this.file);
    } catch (error) {
      console.error('[NAYZAK] Failed to save settings:', error);
    }
  }

  flush() {
    if (this.saveTimer) {
      clearTimeout(this.saveTimer);
      this.saveTimer = null;
    }
    this.save();
  }
}

module.exports = { SettingsStore, DEFAULT_SETTINGS };
