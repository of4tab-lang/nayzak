'use strict';

const { screen } = require('electron');
const { mouse } = require('@nut-tree-fork/nut-js');

let coordinateSpace = null; // 'physical' | 'dip'

function close(a, b, tolerance = 3) {
  return Math.abs(a.x - b.x) <= tolerance && Math.abs(a.y - b.y) <= tolerance;
}

/**
 * nut.js reports Windows cursor coordinates in physical pixels, while Electron's
 * screen API works in DIPs. On scaled displays those differ, so detect the space
 * once and convert every coordinate with Electron's own display mapping.
 */
async function ensureCoordinateSpace() {
  if (coordinateSpace) return coordinateSpace;

  try {
    const dipPoint = screen.getCursorScreenPoint();
    const nutPoint = await mouse.getPosition();

    if (typeof screen.dipToScreenPoint === 'function') {
      const physicalPoint = screen.dipToScreenPoint(dipPoint);
      if (close(nutPoint, physicalPoint, 4)) {
        coordinateSpace = 'physical';
        return coordinateSpace;
      }
    }

    if (close(nutPoint, dipPoint, 4)) {
      coordinateSpace = 'dip';
      return coordinateSpace;
    }

    // Last-resort heuristic for older runtimes: if the pointer is 1:1 with the
    // scaled DIP position, nut is using physical pixels.
    const display = screen.getDisplayNearestPoint(dipPoint);
    const scale = display?.scaleFactor || 1;
    if (
      Math.abs(nutPoint.x - dipPoint.x * scale) <= 4 &&
      Math.abs(nutPoint.y - dipPoint.y * scale) <= 4
    ) {
      coordinateSpace = 'physical';
    } else {
      coordinateSpace = 'dip';
    }
  } catch (error) {
    coordinateSpace = 'dip';
  }

  return coordinateSpace;
}

function dipToNative(point) {
  const x = Number(point?.x);
  const y = Number(point?.y);
  if (!Number.isFinite(x) || !Number.isFinite(y)) {
    throw new Error('إحداثيات غير صالحة');
  }

  if (coordinateSpace === 'physical' && typeof screen.dipToScreenPoint === 'function') {
    const converted = screen.dipToScreenPoint({ x: Math.round(x), y: Math.round(y) });
    return { x: Math.round(converted.x), y: Math.round(converted.y) };
  }

  return { x: Math.round(x), y: Math.round(y) };
}

function cursorDipPoint() {
  return screen.getCursorScreenPoint();
}

function screenSnapshot() {
  return screen.getAllDisplays().map((display) => ({
    id: display.id,
    bounds: display.bounds,
    workArea: display.workArea,
    scaleFactor: display.scaleFactor,
  }));
}

module.exports = {
  ensureCoordinateSpace,
  dipToNative,
  cursorDipPoint,
  screenSnapshot,
  getCoordinateSpace: () => coordinateSpace,
};
