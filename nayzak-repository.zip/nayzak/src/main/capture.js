'use strict';

const path = require('node:path');
const { BrowserWindow, ipcMain, screen } = require('electron');

class PointPicker {
  constructor() {
    this.windows = [];
    this.windowContents = new Set();
    this.active = null;
    this.session = 0;
    this.preloadPath = path.join(__dirname, '..', 'preload', 'overlay-preload.js');
    this.overlayPath = path.join(__dirname, '..', 'overlay', 'index.html');
  }

  registerIpc() {
    ipcMain.on('overlay:submit', (event, point) => {
      if (!this.windowContents.has(event.sender.id) || !this.active) return;
      const x = Number(point?.x);
      const y = Number(point?.y);
      if (!Number.isFinite(x) || !Number.isFinite(y)) {
        this.#resolve(null);
        return;
      }
      this.#resolve({
        x: Math.round(Math.max(-100_000, Math.min(100_000, x))),
        y: Math.round(Math.max(-100_000, Math.min(100_000, y))),
      });
    });

    ipcMain.on('overlay:cancel', (event) => {
      if (!this.windowContents.has(event.sender.id) || !this.active) return;
      this.#resolve(null);
    });
  }

  pick() {
    if (this.active) this.#resolve(null);

    return new Promise((resolve) => {
      this.session += 1;
      this.active = { resolve, session: this.session };
      const session = this.session;
      const displays = screen.getAllDisplays();
      const cursor = screen.getCursorScreenPoint();
      const focusedDisplay = screen.getDisplayNearestPoint(cursor);

      for (const display of displays) {
        const win = new BrowserWindow({
          x: display.bounds.x,
          y: display.bounds.y,
          width: display.bounds.width,
          height: display.bounds.height,
          frame: false,
          transparent: true,
          backgroundColor: '#00000000',
          alwaysOnTop: true,
          skipTaskbar: true,
          resizable: false,
          movable: false,
          minimizable: false,
          maximizable: false,
          fullscreenable: false,
          hasShadow: false,
          show: false,
          enableLargerThanScreen: true,
          webPreferences: {
            preload: this.preloadPath,
            contextIsolation: true,
            nodeIntegration: false,
            sandbox: true,
            spellcheck: false,
          },
        });

        win.setMenuBarVisibility(false);
        try {
          win.setAlwaysOnTop(true, 'screen-saver');
        } catch {
          // Non-fatal; the regular always-on-top flag still applies.
        }
        try {
          win.setVisibleOnAllWorkspaces(true, { visibleOnFullScreen: true });
        } catch {
          // macOS-only behavior on some versions.
        }

        const contentsId = win.webContents.id;
        this.windows.push(win);
        this.windowContents.add(contentsId);

        win.on('closed', () => {
          this.windowContents.delete(contentsId);
          if (this.active && this.active.session === session) {
            const remaining = this.windows.filter((candidate) => !candidate.isDestroyed());
            if (remaining.length === 0) this.#resolve(null);
          }
        });

        win.loadFile(this.overlayPath, {
          query: {
            index: String(displays.findIndex((item) => item.id === display.id) + 1),
            total: String(displays.length),
          },
        });

        win.once('ready-to-show', () => {
          if (!this.active || this.active.session !== session) {
            if (!win.isDestroyed()) win.destroy();
            return;
          }

          if (display.id === focusedDisplay.id) {
            win.show();
            win.focus();
            win.moveTop();
          } else {
            win.showInactive();
          }
        });
      }
    });
  }

  #resolve(result) {
    const active = this.active;
    if (!active) return;
    this.active = null;
    this.#closeWindows();
    active.resolve(result);
  }

  #closeWindows() {
    const windows = this.windows;
    this.windows = [];
    this.windowContents.clear();
    for (const win of windows) {
      if (!win.isDestroyed()) win.destroy();
    }
  }

  destroy() {
    this.#resolve(null);
  }
}

module.exports = { PointPicker };
