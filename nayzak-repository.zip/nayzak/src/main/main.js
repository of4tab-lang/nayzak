'use strict';

const path = require('node:path');
const fs = require('node:fs');
const {
  app,
  BrowserWindow,
  Menu,
  Tray,
  Notification,
  dialog,
  globalShortcut,
  ipcMain,
  nativeImage,
  nativeTheme,
  screen,
  shell,
  systemPreferences,
} = require('electron');

const screenshotPath = process.env.NAYZAK_SHOT || '';
if (screenshotPath) {
  app.setPath('userData', path.join(app.getPath('temp'), 'nayzak-screenshot-profile'));
}

const { SettingsStore } = require('./settings');
const { ClickEngine } = require('./engine');
const { PointPicker } = require('./capture');
const { ensureCoordinateSpace, cursorDipPoint } = require('./coords');
const { APP_ID } = require('../shared/constants');

const gotLock = app.requestSingleInstanceLock();
if (!gotLock) {
  app.quit();
}

app.commandLine.appendSwitch('lang', 'en-US');
app.setAppUserModelId(APP_ID);
nativeTheme.themeSource = 'dark';

let mainWindow = null;
let tray = null;
let trayMenuRunning = null;
let isQuitting = false;
let quitDialogOpen = false;
let hotkeysSuspended = false;
let hotkeyStatus = {
  toggle: { ok: false, accelerator: '', error: 'لم يتم التسجيل بعد' },
  panic: { ok: false, accelerator: '', error: 'لم يتم التسجيل بعد' },
};
let boundsSaveTimer = null;
let screenshotDone = false;

const store = new SettingsStore();
const engine = new ClickEngine();
const picker = new PointPicker();

function assetsRoot() {
  return path.join(app.getAppPath(), 'assets');
}

function isMac() {
  return process.platform === 'darwin';
}

function sendToRenderer(channel, payload) {
  if (mainWindow && !mainWindow.isDestroyed() && !mainWindow.webContents.isDestroyed()) {
    mainWindow.webContents.send(channel, payload);
  }
}

function showWindow() {
  if (!mainWindow || mainWindow.isDestroyed()) {
    createMainWindow();
    return;
  }
  if (mainWindow.isMinimized()) mainWindow.restore();
  if (!mainWindow.isVisible()) mainWindow.show();
  mainWindow.focus();
}

function notify(title, body) {
  try {
    if (!Notification.isSupported()) return;
    const mark = path.join(assetsRoot(), 'mark.png');
    const notification = new Notification({
      title,
      body,
      silent: true,
      icon: fs.existsSync(mark) ? mark : undefined,
    });
    notification.show();
  } catch {
    // Notifications are a nice-to-have.
  }
}

function sendToggleRequest() {
  if (!mainWindow || mainWindow.isDestroyed()) return;
  sendToRenderer('hotkey:toggle');
}

function registerHotkeys(candidate) {
  if (!candidate || typeof candidate.toggle !== 'string' || typeof candidate.panic !== 'string') {
    return { ok: false, error: 'اختصار غير صالح' };
  }
  if (candidate.toggle === candidate.panic) {
    return { ok: false, error: 'لا يمكن استخدام الاختصار نفسه للتشغيل والإيقاف الطارئ' };
  }

  globalShortcut.unregisterAll();
  const status = {
    toggle: { ok: false, accelerator: candidate.toggle, error: '' },
    panic: { ok: false, accelerator: candidate.panic, error: '' },
  };

  const handlers = {
    toggle: () => sendToggleRequest(),
    panic: () => {
      engine.stop('panic');
      if (!mainWindow || !mainWindow.isVisible()) {
        notify('إيقاف طارئ', 'تم إيقاف جميع عمليات النقر.');
      }
    },
  };

  let failedKey = null;
  for (const key of ['toggle', 'panic']) {
    try {
      const registered = globalShortcut.register(candidate[key], handlers[key]);
      status[key].ok = Boolean(registered);
      if (!registered) {
        status[key].error = 'الاختصار محجوز من تطبيق آخر';
        failedKey = key;
      }
    } catch (error) {
      status[key].ok = false;
      status[key].error = 'صيغة اختصار غير صالحة';
      failedKey = key;
    }
  }

  if (failedKey) {
    globalShortcut.unregisterAll();
    hotkeyStatus = status;
    return { ok: false, error: `تعذر تسجيل اختصار ${failedKey === 'toggle' ? 'التشغيل' : 'الإيقاف'}` };
  }

  hotkeyStatus = status;
  hotkeysSuspended = false;
  return { ok: true, status };
}

function applyHotkeysFromStore() {
  const result = registerHotkeys(store.hotkeys);
  if (!result.ok) {
    // If the stored combination became unavailable, keep the app usable by
    // trying the factory shortcuts once, but do not overwrite the user's choice.
    const defaults = { toggle: 'F8', panic: 'F9' };
    if (store.hotkeys.toggle !== defaults.toggle || store.hotkeys.panic !== defaults.panic) {
      const fallback = registerHotkeys(defaults);
      if (fallback.ok) {
        hotkeyStatus = fallback.status;
        store.setHotkeys(defaults);
        return;
      }
    }
    hotkeyStatus = {
      toggle: { ok: false, accelerator: store.hotkeys.toggle, error: 'تعذر تسجيل الاختصار' },
      panic: { ok: false, accelerator: store.hotkeys.panic, error: 'تعذر تسجيل الاختصار' },
    };
  }
}

function suspendHotkeys() {
  globalShortcut.unregisterAll();
  hotkeysSuspended = true;
}

function resumeHotkeys() {
  if (!hotkeysSuspended) return;
  applyHotkeysFromStore();
  hotkeysSuspended = false;
  sendToRenderer('hotkeys:status', hotkeyStatus);
}

function normalizeBounds() {
  if (screenshotPath) {
    const width = Number(process.env.NAYZAK_SHOT_WIDTH) || 1180;
    const height = Number(process.env.NAYZAK_SHOT_HEIGHT) || 800;
    return {
      width: Math.max(1000, Math.min(4000, Math.round(width))),
      height: Math.max(690, Math.min(3000, Math.round(height))),
      x: undefined,
      y: undefined,
      maximized: false,
    };
  }

  const saved = store.windowState;
  if (!saved) return { width: 1180, height: 800, x: undefined, y: undefined, maximized: false };

  const displays = screen.getAllDisplays();
  const visible = displays.some((display) => {
    const area = display.workArea;
    return (
      saved.x !== null &&
      saved.y !== null &&
      saved.x < area.x + area.width - 80 &&
      saved.x + saved.width > area.x + 80 &&
      saved.y < area.y + area.height - 40 &&
      saved.y + saved.height > area.y + 40
    );
  });

  return {
    width: saved.width,
    height: saved.height,
    x: visible ? saved.x : undefined,
    y: visible ? saved.y : undefined,
    maximized: saved.maximized,
  };
}

function createMainWindow() {
  const bounds = normalizeBounds();
  const windowOptions = {
    width: bounds.width,
    height: bounds.height,
    minWidth: 1000,
    minHeight: 690,
    x: bounds.x,
    y: bounds.y,
    show: false,
    frame: false,
    title: 'نيزك | NAYZAK',
    backgroundColor: '#070910',
    autoHideMenuBar: true,
    roundedCorners: true,
    icon: isMac() ? undefined : path.join(assetsRoot(), 'mark.png'),
    webPreferences: {
      preload: path.join(__dirname, '..', 'preload', 'preload.js'),
      contextIsolation: true,
      nodeIntegration: false,
      sandbox: true,
      spellcheck: false,
      devTools: !app.isPackaged,
    },
  };

  if (isMac()) {
    windowOptions.titleBarStyle = 'hidden';
    windowOptions.trafficLightPosition = { x: 18, y: 18 };
  }

  mainWindow = new BrowserWindow(windowOptions);

  const query = {};
  if (process.env.NAYZAK_SHOT_VIEW) query.view = process.env.NAYZAK_SHOT_VIEW;
  if (process.env.NAYZAK_SHOT_DEMO) query.demo = '1';

  if (Object.keys(query).length) {
    mainWindow.loadFile(path.join(__dirname, '..', 'renderer', 'index.html'), { query });
  } else {
    mainWindow.loadFile(path.join(__dirname, '..', 'renderer', 'index.html'));
  }

  mainWindow.once('ready-to-show', () => {
    if (bounds.maximized) mainWindow.maximize();
    mainWindow.show();
    mainWindow.focus();
    if (process.argv.includes('--dev')) {
      mainWindow.webContents.openDevTools({ mode: 'detach' });
    }
  });

  mainWindow.webContents.setWindowOpenHandler(() => ({ action: 'deny' }));
  mainWindow.webContents.on('will-navigate', (event) => event.preventDefault());

  mainWindow.on('close', (event) => {
    if (isQuitting) return;
    event.preventDefault();
    handleWindowClose();
  });

  const saveBounds = () => {
    if (!mainWindow || mainWindow.isDestroyed() || mainWindow.isMaximized()) return;
    const normal = mainWindow.getNormalBounds();
    store.setWindowState({
      width: normal.width,
      height: normal.height,
      x: normal.x,
      y: normal.y,
      maximized: false,
    });
  };

  const scheduleBoundsSave = () => {
    if (boundsSaveTimer) clearTimeout(boundsSaveTimer);
    boundsSaveTimer = setTimeout(saveBounds, 450);
  };

  mainWindow.on('resize', scheduleBoundsSave);
  mainWindow.on('move', scheduleBoundsSave);
  mainWindow.on('maximize', () => {
    const normal = mainWindow.getNormalBounds();
    store.setWindowState({ ...normal, maximized: true });
    sendToRenderer('window:maximized', true);
  });
  mainWindow.on('unmaximize', () => {
    saveBounds();
    sendToRenderer('window:maximized', false);
  });
  mainWindow.on('closed', () => {
    mainWindow = null;
  });

  if (screenshotPath) {
    mainWindow.webContents.once('did-finish-load', () => {
      setTimeout(async () => {
        if (screenshotDone || !mainWindow || mainWindow.isDestroyed()) return;
        screenshotDone = true;
        try {
          const image = await mainWindow.webContents.capturePage();
          fs.mkdirSync(path.dirname(screenshotPath), { recursive: true });
          fs.writeFileSync(screenshotPath, image.toPNG());
          console.log(`[NAYZAK] Screenshot written to ${screenshotPath}`);
        } catch (error) {
          console.error('[NAYZAK] Screenshot failed:', error);
        } finally {
          app.exit(0);
        }
      }, 1800);
    });
  }
}

async function handleWindowClose() {
  if (!mainWindow || mainWindow.isDestroyed()) return;

  if (store.preferences.tray) {
    mainWindow.hide();
    if (!store.preferences.trayHintShown) {
      store.setPreferences({ trayHintShown: true });
      notify('نيزك يعمل في الخلفية', 'استخدم أيقونة نيزك بجانب الساعة للعودة، أو اختصار التشغيل من أي مكان.');
    }
    return;
  }

  await requestQuit({ askIfRunning: true, showWindowIfHidden: true });
}

async function requestQuit({ askIfRunning = true, showWindowIfHidden = false, force = false } = {}) {
  if (isQuitting) return true;
  if (quitDialogOpen) return false;

  if (askIfRunning && engine.running && !force) {
    quitDialogOpen = true;
    if (showWindowIfHidden) showWindow();
    const options = {
      type: 'question',
      title: 'إيقاف نيزك',
      message: 'عمليات النقر قيد التشغيل',
      detail: 'سيتم إيقاف كل العمليات قبل إغلاق التطبيق. هل تريد المتابعة؟',
      buttons: ['إيقاف وخروج', 'إلغاء'],
      defaultId: 0,
      cancelId: 1,
      noLink: true,
    };
    const parent = mainWindow && !mainWindow.isDestroyed() ? mainWindow : undefined;
    const result = parent ? await dialog.showMessageBox(parent, options) : await dialog.showMessageBox(options);
    quitDialogOpen = false;
    if (result.response !== 0) return false;
  }

  isQuitting = true;
  if (engine.running) engine.stop('quit');
  if (boundsSaveTimer) clearTimeout(boundsSaveTimer);
  if (mainWindow && !mainWindow.isDestroyed() && !mainWindow.isMaximized()) {
    const normal = mainWindow.getNormalBounds();
    store.setWindowState({ ...normal, maximized: false });
  }
  store.flush();
  globalShortcut.unregisterAll();
  if (tray) {
    tray.destroy();
    tray = null;
  }
  picker.destroy();
  app.quit();
  return true;
}

function buildTrayMenu() {
  if (!tray) return;
  const running = engine.running;

  const menu = Menu.buildFromTemplate([
    {
      label: 'فتح نيزك',
      click: () => showWindow(),
    },
    { type: 'separator' },
    {
      label: running ? 'إيقاف التشغيل' : 'تشغيل الوضع الحالي',
      click: () => {
        sendToggleRequest();
      },
    },
    {
      label: 'إيقاف طارئ',
      enabled: running,
      click: () => {
        engine.stop('panic');
        showWindow();
      },
    },
    { type: 'separator' },
    {
      label: 'خروج',
      click: () => {
        void requestQuit({ askIfRunning: true, showWindowIfHidden: false });
      },
    },
  ]);

  tray.setContextMenu(menu);
  tray.setToolTip(running ? 'نيزك — يعمل الآن' : 'نيزك — جاهز');
}

function createTray() {
  let image;
  if (isMac()) {
    image = nativeImage.createFromPath(assetsRoot() + path.sep + 'trayTemplate.png');
    image.setTemplateImage(true);
  } else {
    image = nativeImage.createFromPath(assetsRoot() + path.sep + 'tray.png');
  }

  if (!image.isEmpty()) {
    tray = new Tray(image);
  } else {
    tray = new Tray(nativeImage.createEmpty());
  }

  buildTrayMenu();

  if (!isMac()) {
    tray.on('click', () => showWindow());
    tray.on('double-click', () => showWindow());
  }
}

function setupEngineEvents() {
  engine.on('state', (state) => {
    sendToRenderer('engine:state', state);
    if (tray && trayMenuRunning !== state.running) {
      trayMenuRunning = state.running;
      buildTrayMenu();
    }
  });

  engine.on('timer-expired', ({ action }) => {
    engine.stop('timer');
    if (action === 'quit') {
      setTimeout(() => {
        void requestQuit({ askIfRunning: false, force: true });
      }, 180);
    } else {
      notify('مؤقت نيزك', 'انتهى الوقت المحدد وتم إيقاف العمليات.');
    }
  });
}

function setupIpc() {
  picker.registerIpc();

  ipcMain.handle('app:bootstrap', (event) => {
    if (!isTrustedSender(event)) return null;
    return {
      version: app.getVersion(),
      platform: process.platform,
      arch: process.arch,
      isPackaged: app.isPackaged,
      preferences: store.preferences,
      hotkeys: store.hotkeys,
      hotkeyStatus,
      ui: store.ui,
      engine: engine.getState(),
      accessibility:
        process.platform === 'darwin'
          ? systemPreferences.isTrustedAccessibilityClient(false)
          : true,
      electron: process.versions.electron,
    };
  });

  ipcMain.handle('engine:start', async (event, payload) => {
    if (!isTrustedSender(event)) return { ok: false, error: 'طلب غير مصرح به' };
    const mode = payload?.mode;
    const config = payload?.config;

    if (process.platform === 'darwin' && !systemPreferences.isTrustedAccessibilityClient(true)) {
      return {
        ok: false,
        code: 'ACCESSIBILITY',
        error:
          'امنح نيزك صلاحية «إمكانية الوصول» من إعدادات النظام ثم أعد المحاولة. تحتاج أتمتة الماوس إلى هذه الصلاحية على macOS.',
      };
    }

    try {
      await ensureCoordinateSpace();
      await engine.start(mode, config);
      return { ok: true, state: engine.getState() };
    } catch (error) {
      return { ok: false, error: error?.message || 'تعذر بدء التشغيل' };
    }
  });

  ipcMain.handle('engine:stop', (event) => {
    if (!isTrustedSender(event)) return { ok: false };
    return { ok: true, state: engine.stop('manual') };
  });

  ipcMain.handle('engine:get-state', (event) => {
    if (!isTrustedSender(event)) return null;
    return engine.getState();
  });

  ipcMain.handle('ui:save', (event, ui) => {
    if (!isTrustedSender(event)) return { ok: false };
    store.setUi(ui);
    return { ok: true };
  });

  ipcMain.handle('prefs:save', (event, patch) => {
    if (!isTrustedSender(event)) return { ok: false };
    if (!patch || typeof patch !== 'object') return { ok: false };

    if (patch.autoLaunch === true && !app.isPackaged) {
      return {
        ok: false,
        error: 'بدء التشغيل التلقائي متاح بعد تثبيت التطبيق.',
        preferences: store.preferences,
      };
    }

    store.setPreferences(patch);

    if (Object.hasOwn(patch, 'autoLaunch') && app.isPackaged) {
      try {
        app.setLoginItemSettings({
          openAtLogin: Boolean(patch.autoLaunch),
          openAsHidden: false,
        });
      } catch (error) {
        return {
          ok: false,
          error: 'تعذر تحديث إعدادات بدء التشغيل مع النظام.',
          preferences: store.preferences,
        };
      }
    }

    return { ok: true, preferences: store.preferences };
  });

  ipcMain.handle('hotkeys:set', (event, hotkeys) => {
    if (!isTrustedSender(event)) return { ok: false, error: 'طلب غير مصرح به' };

    const candidate = {
      toggle: String(hotkeys?.toggle || '').trim(),
      panic: String(hotkeys?.panic || '').trim(),
    };
    if (!candidate.toggle || !candidate.panic) {
      return { ok: false, error: 'حدد اختصارًا للتشغيل وآخر للإيقاف الطارئ' };
    }
    if (candidate.toggle.length > 80 || candidate.panic.length > 80) {
      return { ok: false, error: 'الاختصار طويل جدًا' };
    }

    const result = registerHotkeys(candidate);
    if (!result.ok) {
      applyHotkeysFromStore();
      return { ok: false, error: result.error, status: hotkeyStatus };
    }

    store.setHotkeys(candidate);
    return { ok: true, hotkeys: candidate, status: hotkeyStatus };
  });

  ipcMain.handle('hotkeys:suspend', (event) => {
    if (!isTrustedSender(event)) return { ok: false };
    suspendHotkeys();
    return { ok: true };
  });

  ipcMain.handle('hotkeys:resume', (event) => {
    if (!isTrustedSender(event)) return { ok: false };
    resumeHotkeys();
    return { ok: true, status: hotkeyStatus };
  });

  ipcMain.handle('capture:point', async (event) => {
    if (!isTrustedSender(event)) return null;
    return picker.pick();
  });

  ipcMain.handle('cursor:get', (event) => {
    if (!isTrustedSender(event)) return null;
    return cursorDipPoint();
  });

  ipcMain.handle('window:minimize', (event) => {
    if (!isTrustedSender(event)) return;
    mainWindow?.minimize();
  });

  ipcMain.handle('window:maximize', (event) => {
    if (!isTrustedSender(event)) return;
    if (!mainWindow) return;
    if (mainWindow.isMaximized()) mainWindow.unmaximize();
    else mainWindow.maximize();
  });

  ipcMain.handle('window:close', (event) => {
    if (!isTrustedSender(event)) return;
    mainWindow?.close();
  });

  ipcMain.handle('window:is-maximized', (event) => {
    if (!isTrustedSender(event)) return false;
    return Boolean(mainWindow?.isMaximized());
  });

  ipcMain.handle('app:quit', async (event) => {
    if (!isTrustedSender(event)) return { ok: false };
    const didQuit = await requestQuit({ askIfRunning: true, showWindowIfHidden: true });
    return { ok: didQuit };
  });

  ipcMain.handle('app:open-accessibility', async (event) => {
    if (!isTrustedSender(event)) return { ok: false };
    if (process.platform !== 'darwin') return { ok: false };
    try {
      await shell.openExternal(
        'x-apple.systempreferences:com.apple.preference.security?Privacy_Accessibility',
      );
      return { ok: true };
    } catch {
      return { ok: false };
    }
  });

  ipcMain.handle('app:open-external', async (event, url) => {
    if (!isTrustedSender(event)) return { ok: false };
    if (typeof url !== 'string' || !/^https:\/\//i.test(url)) return { ok: false };
    try {
      await shell.openExternal(url);
      return { ok: true };
    } catch {
      return { ok: false };
    }
  });
}

function isTrustedSender(event) {
  return Boolean(
    mainWindow &&
      !mainWindow.isDestroyed() &&
      event.sender &&
      event.sender.id === mainWindow.webContents.id,
  );
}

function setupAppMenu() {
  if (isMac()) {
    const template = [
      {
        label: 'NAYZAK',
        submenu: [
          { role: 'about' },
          { type: 'separator' },
          { role: 'hide' },
          { role: 'hideOthers' },
          { role: 'unhide' },
          { type: 'separator' },
          { role: 'quit' },
        ],
      },
      { role: 'editMenu' },
      { role: 'windowMenu' },
    ];
    Menu.setApplicationMenu(Menu.buildFromTemplate(template));
  } else {
    Menu.setApplicationMenu(null);
  }
}

async function bootstrapApp() {
  setupAppMenu();
  setupIpc();
  setupEngineEvents();
  createMainWindow();
  createTray();
  applyHotkeysFromStore();

  if (app.isPackaged) {
    try {
      app.setLoginItemSettings({
        openAtLogin: store.preferences.autoLaunch,
        openAsHidden: false,
      });
    } catch {
      // Ignore platform-specific failures.
    }
  }

  sendToRenderer('hotkeys:status', hotkeyStatus);
}

app.whenReady().then(() => {
  bootstrapApp();

  app.on('activate', () => {
    if (!mainWindow || mainWindow.isDestroyed()) createMainWindow();
    else showWindow();
  });
});

app.on('second-instance', () => {
  showWindow();
});

app.on('before-quit', () => {
  isQuitting = true;
  if (engine.running) engine.stop('quit');
  globalShortcut.unregisterAll();
});

app.on('will-quit', () => {
  store.flush();
  try {
    engine.stop('quit');
  } catch {
    // Ignore.
  }
  globalShortcut.unregisterAll();
});

app.on('window-all-closed', () => {
  if (process.platform !== 'darwin' && !store.preferences.tray) {
    app.quit();
  }
});

process.on('uncaughtException', (error) => {
  console.error('[NAYZAK] Uncaught exception:', error);
});

process.on('unhandledRejection', (error) => {
  console.error('[NAYZAK] Unhandled rejection:', error);
});
