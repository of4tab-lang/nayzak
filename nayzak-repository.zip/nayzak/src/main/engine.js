'use strict';

const { EventEmitter } = require('node:events');
const { powerMonitor, powerSaveBlocker } = require('electron');
const { mouse, Button, Point } = require('@nut-tree-fork/nut-js');
const { dipToNative, cursorDipPoint, ensureCoordinateSpace } = require('./coords');

const BUTTONS = {
  left: Button.LEFT,
  middle: Button.MIDDLE,
  right: Button.RIGHT,
};

const MAX_DELAY = 86_400_000;
const MAX_POINTS = 200;

function integer(value, fallback, min, max) {
  const parsed = Number(value);
  if (!Number.isFinite(parsed)) return fallback;
  return Math.min(max, Math.max(min, Math.round(parsed)));
}

function decimal(value, fallback, min, max) {
  const parsed = Number(value);
  if (!Number.isFinite(parsed)) return fallback;
  return Math.min(max, Math.max(min, parsed));
}

function button(value) {
  return Object.hasOwn(BUTTONS, value) ? value : 'left';
}

function repeat(value, fallbackMode = 'infinite') {
  if (!value || typeof value !== 'object') return { mode: fallbackMode, count: 100 };
  if (value.mode === 'count') {
    return { mode: 'count', count: integer(value.count, 100, 1, 100_000_000) };
  }
  return { mode: 'infinite', count: 0 };
}

function normalizeSingle(raw) {
  const config = raw && typeof raw === 'object' ? raw : {};
  const target = config.target && config.target.mode === 'fixed'
    ? {
        mode: 'fixed',
        x: integer(config.target.x, 0, -100_000, 100_000),
        y: integer(config.target.y, 0, -100_000, 100_000),
      }
    : { mode: 'cursor' };

  return {
    target,
    intervalMs: integer(config.intervalMs, 100, 1, MAX_DELAY),
    button: button(config.button),
    repeat: repeat(config.repeat),
    startDelayMs: integer(config.startDelayMs, 0, 0, 30_000),
  };
}

function normalizeMulti(raw) {
  const config = raw && typeof raw === 'object' ? raw : {};
  const points = Array.isArray(config.points) ? config.points.slice(0, MAX_POINTS) : [];
  if (points.length === 0) {
    throw new Error('أضف نقطة واحدة على الأقل إلى المسار قبل التشغيل');
  }

  return {
    points: points.map((point, index) => ({
      index,
      x: integer(point && point.x, 0, -100_000, 100_000),
      y: integer(point && point.y, 0, -100_000, 100_000),
      delayMs: integer(point && point.delayMs, 250, 0, MAX_DELAY),
    })),
    button: button(config.button),
    repeat: repeat(config.repeat),
    seriesDelayMs: integer(config.seriesDelayMs, 500, 0, MAX_DELAY),
    startDelayMs: integer(config.startDelayMs, 0, 0, 30_000),
  };
}

function normalizeSmart(raw) {
  const config = raw && typeof raw === 'object' ? raw : {};
  const clickRaw = config.click && typeof config.click === 'object' ? config.click : {};
  const microRaw =
    clickRaw.microPause && typeof clickRaw.microPause === 'object' ? clickRaw.microPause : {};
  const jiggleRaw = config.jiggle && typeof config.jiggle === 'object' ? config.jiggle : {};
  const timerRaw = config.timer && typeof config.timer === 'object' ? config.timer : {};

  const microMin = integer(microRaw.minMs, 180, 20, 600_000);
  const microMax = Math.max(microMin, integer(microRaw.maxMs, 450, 20, 600_000));

  const normalized = {
    click: {
      enabled: Boolean(clickRaw.enabled),
      intervalMs: integer(clickRaw.intervalMs, 120, 1, MAX_DELAY),
      variancePct: integer(clickRaw.variancePct, 35, 0, 95),
      jitterPx: integer(clickRaw.jitterPx, 3, 0, 250),
      button: button(clickRaw.button),
      microPause: {
        enabled: Boolean(microRaw.enabled),
        every: integer(microRaw.every, 12, 2, 10_000),
        minMs: microMin,
        maxMs: microMax,
      },
    },
    jiggle: {
      enabled: Boolean(jiggleRaw.enabled),
      intervalSec: integer(jiggleRaw.intervalSec, 45, 1, 3600),
      idleOnly: jiggleRaw.idleOnly !== false,
    },
    timer: {
      enabled: Boolean(timerRaw.enabled),
      minutes: integer(timerRaw.minutes, 30, 1, 1440),
      action: timerRaw.action === 'quit' ? 'quit' : 'stop',
    },
    startDelayMs: integer(config.startDelayMs, 0, 0, 30_000),
  };

  if (!normalized.click.enabled && !normalized.jiggle.enabled) {
    throw new Error('فعّل النقر البشري أو مانع الخمول أولًا');
  }

  return normalized;
}

class ClickEngine extends EventEmitter {
  constructor() {
    super();
    this.running = false;
    this.mode = null;
    this.stopReason = null;
    this.startedAt = 0;
    this._finalElapsedMs = 0;
    this.clicks = 0;
    this.jiggles = 0;
    this.currentIndex = -1;
    this.currentPoint = null;
    this.error = null;
    this._gen = 0;
    this._starting = false;
    this._loops = new Set();
    this._ticker = null;
    this._waits = new Set();
    this._countdownEndsAt = 0;
    this._timerEndsAt = 0;
    this._timerFired = false;
    this._sleepAction = 'stop';
    this._powerBlockerId = null;

    mouse.config.autoDelayMs = 0;
    mouse.config.mouseSpeed = 12_000;
    this.on('error', () => {});
  }

  getState() {
    const now = Date.now();
    const elapsedMs = this.running && this.startedAt
      ? Math.max(0, now - this.startedAt)
      : this._finalElapsedMs;
    const countdownMs =
      this.running && this._countdownEndsAt ? Math.max(0, this._countdownEndsAt - now) : 0;
    const timerRemainingMs =
      this.running && this._timerEndsAt ? Math.max(0, this._timerEndsAt - now) : null;
    const cps = elapsedMs > 150 ? Math.round((this.clicks / (elapsedMs / 1000)) * 10) / 10 : 0;

    let progress = null;
    if (this.running && this.currentIndex >= 0) progress = this.currentIndex;

    return {
      running: this.running,
      mode: this.mode,
      stopReason: this.stopReason,
      clicks: this.clicks,
      jiggles: this.jiggles,
      elapsedMs,
      countdownMs,
      timerRemainingMs,
      cps,
      currentIndex: this.currentIndex,
      currentPoint: this.currentPoint,
      progress,
      error: this.error,
    };
  }

  emitState() {
    this.emit('state', this.getState());
  }

  async start(mode, rawConfig) {
    if (this.running || this._starting) {
      throw new Error('يوجد تشغيل نشط بالفعل');
    }

    this._starting = true;
    try {
      if (this._loops.size > 0) {
        await Promise.race([
          Promise.allSettled([...this._loops]),
          new Promise((resolve) => setTimeout(resolve, 600)),
        ]);
      }

      let config;
      if (mode === 'single') config = normalizeSingle(rawConfig);
      else if (mode === 'multi') config = normalizeMulti(rawConfig);
      else if (mode === 'smart') config = normalizeSmart(rawConfig);
      else throw new Error('وضع تشغيل غير معروف');

      await ensureCoordinateSpace();

      this.mode = mode;
      this.stopReason = null;
      this.error = null;
      this.startedAt = 0;
      this._finalElapsedMs = 0;
      this.clicks = 0;
      this.jiggles = 0;
      this.currentIndex = -1;
      this.currentPoint = null;
      this._countdownEndsAt = 0;
      this._timerEndsAt = 0;
      this._timerFired = false;
      this._sleepAction = 'stop';
      this.running = true;
      this._gen += 1;
      const generation = this._gen;

      if (mode === 'smart' && config.jiggle.enabled) {
        this.#startPowerBlocker();
      }

      this.#startTicker();
      this.emitState();

      const loop = this.#execute(generation, mode, config)
        .catch((error) => {
          if (this._gen !== generation) return;
          const message = 'تعذر تنفيذ العملية. تأكد من صلاحيات التحكم بالماوس وحاول مجددًا.';
          this.error = { code: 'NATIVE', message, detail: error?.message || String(error) };
          if (this.running) this.stop('error');
        })
        .finally(() => {
          this._loops.delete(loop);
        });

      this._loops.add(loop);
      return this.getState();
    } finally {
      this._starting = false;
    }
  }

  stop(reason = 'manual') {
    if (!this.running) return this.getState();

    this.#updateElapsed();
    this.running = false;
    this.stopReason = reason;
    this._gen += 1;
    this._countdownEndsAt = 0;
    this.#cleanup();
    this.emitState();
    this.emit('stopped', this.getState());
    return this.getState();
  }

  async #execute(generation, mode, config) {
    if (mode === 'single') {
      return this.#runSingle(generation, config);
    }
    if (mode === 'multi') {
      return this.#runMulti(generation, config);
    }
    return this.#runSmart(generation, config);
  }

  async #runSingle(generation, config) {
    const prepared = await this.#prepare(generation, config.startDelayMs, null);
    if (!prepared) return;

    const point = config.target.mode === 'fixed'
      ? { x: config.target.x, y: config.target.y }
      : cursorDipPoint();
    const nativePoint = dipToNative(point);

    this.currentPoint = point;
    this.currentIndex = 0;
    this.emitState();

    const limit = config.repeat.mode === 'count' ? config.repeat.count : Infinity;
    let nextAt = performance.now();

    while (this.#active(generation) && this.clicks < limit) {
      if (!(await this.#positionAndClick(nativePoint, config.button, generation))) break;
      this.clicks += 1;

      if (this.clicks >= limit) break;

      nextAt += config.intervalMs;
      const now = performance.now();
      if (nextAt < now - 80) nextAt = now + config.intervalMs;
      if (!(await this.#wait(Math.max(0, nextAt - performance.now()), generation))) break;
    }

    if (this._gen === generation) this.#finish('complete');
  }

  async #runMulti(generation, config) {
    const prepared = await this.#prepare(generation, config.startDelayMs, null);
    if (!prepared) return;

    const points = config.points.map((point) => ({
      dip: { x: point.x, y: point.y },
      native: dipToNative(point),
      delayMs: point.delayMs,
    }));

    const seriesLimit = config.repeat.mode === 'count' ? config.repeat.count : Infinity;
    let series = 0;

    while (this.#active(generation) && series < seriesLimit) {
      for (let index = 0; index < points.length; index += 1) {
        if (!this.#active(generation)) break;

        const point = points[index];
        this.currentIndex = index;
        this.currentPoint = point.dip;

        if (!(await this.#positionAndClick(point.native, config.button, generation))) break;
        this.clicks += 1;

        if (point.delayMs > 0) {
          if (!(await this.#wait(point.delayMs, generation))) break;
        }
      }

      series += 1;
      if (!this.#active(generation)) break;
      if (series < seriesLimit && config.seriesDelayMs > 0) {
        if (!(await this.#wait(config.seriesDelayMs, generation))) break;
      }
    }

    if (this._gen === generation) this.#finish('complete');
  }

  async #runSmart(generation, config) {
    const hasClicks = config.click.enabled;
    const startDelay = hasClicks ? config.startDelayMs : 0;
    const prepared = await this.#prepare(generation, startDelay, config.timer);
    if (!prepared) return;

    const tasks = [];
    if (config.jiggle.enabled) tasks.push(this.#runJiggler(generation, config.jiggle));
    if (hasClicks) tasks.push(this.#runHumanClicks(generation, config.click));

    if (tasks.length === 0) {
      this.#finish('complete');
      return;
    }

    await Promise.all(tasks);
    if (this._gen === generation) this.#finish('complete');
  }

  async #runHumanClicks(generation, config) {
    const base = cursorDipPoint();
    let nextAt = performance.now();
    let clickNumber = 0;

    while (this.#active(generation)) {
      let point = base;
      if (config.jitterPx > 0) {
        const angle = Math.random() * Math.PI * 2;
        const radius = Math.sqrt(Math.random()) * config.jitterPx;
        point = {
          x: Math.round(base.x + Math.cos(angle) * radius),
          y: Math.round(base.y + Math.sin(angle) * radius),
        };
      }

      this.currentPoint = point;
      const nativePoint = dipToNative(point);
      if (!(await this.#positionAndClick(nativePoint, config.button, generation))) break;
      this.clicks += 1;
      clickNumber += 1;

      const variance = ((Math.random() * 2 - 1) * config.variancePct) / 100;
      let waitMs = Math.round(config.intervalMs * (1 + variance));
      waitMs = Math.max(1, waitMs);

      if (config.microPause.enabled && clickNumber % config.microPause.every === 0) {
        waitMs += Math.round(
          config.microPause.minMs +
            Math.random() * (config.microPause.maxMs - config.microPause.minMs),
        );
      }

      nextAt += waitMs;
      const now = performance.now();
      if (nextAt < now - 120) nextAt = now + waitMs;
      if (!(await this.#wait(Math.max(0, nextAt - performance.now()), generation))) break;
    }
  }

  async #runJiggler(generation, config) {
    const intervalMs = config.intervalSec * 1000;

    while (this.#active(generation)) {
      if (!(await this.#wait(intervalMs, generation))) break;
      if (!this.#active(generation)) break;

      if (config.idleOnly) {
        const idleSeconds = powerMonitor.getSystemIdleTime();
        if (idleSeconds < config.intervalSec) continue;
      }

      try {
        const origin = await mouse.getPosition();
        if (!this.#active(generation)) break;
        await mouse.setPosition(new Point(origin.x + 1, origin.y));
        await this.#wait(35, generation);
        await mouse.setPosition(new Point(origin.x, origin.y));
        this.jiggles += 1;
      } catch {
        // A single failed jiggle should not stop the entire session.
      }
    }
  }

  async #prepare(generation, delayMs, timer) {
    if (!this.#active(generation)) return false;

    if (delayMs > 0) {
      this._countdownEndsAt = Date.now() + delayMs;
      this.emitState();
      while (this.#active(generation)) {
        const remaining = this._countdownEndsAt - Date.now();
        if (remaining <= 0) break;
        if (!(await this.#wait(Math.min(100, remaining), generation))) return false;
      }
      this._countdownEndsAt = 0;
      if (!this.#active(generation)) return false;
    }

    this.#beginTiming(timer);
    this.emitState();
    return true;
  }

  #beginTiming(timer) {
    this.startedAt = Date.now();
    this._finalElapsedMs = 0;
    if (timer && timer.enabled) {
      this._timerEndsAt = this.startedAt + timer.minutes * 60_000;
      this._sleepAction = timer.action;
    }
  }

  async #positionAndClick(nativePoint, buttonName, generation) {
    if (!this.#active(generation)) return false;
    await mouse.setPosition(new Point(nativePoint.x, nativePoint.y));
    if (!this.#active(generation)) return false;
    await mouse.click(BUTTONS[buttonName] || Button.LEFT);
    return this.#active(generation) || this._gen !== generation;
  }

  #active(generation) {
    return this.running && this._gen === generation;
  }

  #wait(ms, generation) {
    return new Promise((resolve) => {
      if (!this.#active(generation)) {
        resolve(false);
        return;
      }

      const entry = {
        timer: null,
        resolve: null,
      };

      entry.timer = setTimeout(() => {
        this._waits.delete(entry);
        resolve(this.#active(generation));
      }, Math.max(0, ms));

      entry.resolve = () => {
        clearTimeout(entry.timer);
        this._waits.delete(entry);
        resolve(false);
      };

      this._waits.add(entry);
    });
  }

  #startTicker() {
    if (this._ticker) clearInterval(this._ticker);
    this._ticker = setInterval(() => {
      if (!this.running) return;

      if (this._timerEndsAt && Date.now() >= this._timerEndsAt && !this._timerFired) {
        this._timerFired = true;
        this.emit('timer-expired', { action: this._sleepAction });
        return;
      }

      this.emitState();
    }, 100);
  }

  #startPowerBlocker() {
    try {
      if (this._powerBlockerId === null) {
        this._powerBlockerId = powerSaveBlocker.start('prevent-display-sleep');
      }
    } catch {
      this._powerBlockerId = null;
    }
  }

  #stopPowerBlocker() {
    try {
      if (this._powerBlockerId !== null && powerSaveBlocker.isStarted(this._powerBlockerId)) {
        powerSaveBlocker.stop(this._powerBlockerId);
      }
    } catch {
      // Ignore teardown failures.
    } finally {
      this._powerBlockerId = null;
    }
  }

  #updateElapsed() {
    if (this.startedAt) {
      this._finalElapsedMs = Math.max(0, Date.now() - this.startedAt);
    }
  }

  #cleanup() {
    if (this._ticker) {
      clearInterval(this._ticker);
      this._ticker = null;
    }
    for (const entry of [...this._waits]) {
      entry.resolve();
    }
    this._waits.clear();
    this._countdownEndsAt = 0;
    this.#stopPowerBlocker();
  }

  #finish(reason) {
    if (!this.running) return;
    this.#updateElapsed();
    this.running = false;
    this.stopReason = reason;
    this._gen += 1;
    this.#cleanup();
    this.emitState();
    this.emit('stopped', this.getState());
  }
}

module.exports = { ClickEngine };
