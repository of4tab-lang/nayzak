'use strict';

const { contextBridge, ipcRenderer } = require('electron');

function subscribe(channel, callback) {
  const listener = (_event, payload) => {
    if (typeof callback === 'function') callback(payload);
  };
  ipcRenderer.on(channel, listener);
  return () => ipcRenderer.removeListener(channel, listener);
}

contextBridge.exposeInMainWorld('nayzak', {
  bootstrap: () => ipcRenderer.invoke('app:bootstrap'),

  start: (mode, config) => ipcRenderer.invoke('engine:start', { mode, config }),
  stop: () => ipcRenderer.invoke('engine:stop'),
  getEngineState: () => ipcRenderer.invoke('engine:get-state'),

  saveUi: (ui) => ipcRenderer.invoke('ui:save', ui),
  savePreferences: (preferences) => ipcRenderer.invoke('prefs:save', preferences),

  setHotkeys: (hotkeys) => ipcRenderer.invoke('hotkeys:set', hotkeys),
  suspendHotkeys: () => ipcRenderer.invoke('hotkeys:suspend'),
  resumeHotkeys: () => ipcRenderer.invoke('hotkeys:resume'),

  capturePoint: () => ipcRenderer.invoke('capture:point'),
  getCursor: () => ipcRenderer.invoke('cursor:get'),

  minimize: () => ipcRenderer.invoke('window:minimize'),
  maximize: () => ipcRenderer.invoke('window:maximize'),
  close: () => ipcRenderer.invoke('window:close'),
  isMaximized: () => ipcRenderer.invoke('window:is-maximized'),

  quitApp: () => ipcRenderer.invoke('app:quit'),
  openAccessibilitySettings: () => ipcRenderer.invoke('app:open-accessibility'),

  onEngineState: (callback) => subscribe('engine:state', callback),
  onHotkeyToggle: (callback) => subscribe('hotkey:toggle', callback),
  onHotkeysStatus: (callback) => subscribe('hotkeys:status', callback),
  onWindowMaximized: (callback) => subscribe('window:maximized', callback),
});
