'use strict';

const { contextBridge, ipcRenderer } = require('electron');

contextBridge.exposeInMainWorld('overlay', {
  submit: (x, y) => ipcRenderer.send('overlay:submit', { x, y }),
  cancel: () => ipcRenderer.send('overlay:cancel'),
});
