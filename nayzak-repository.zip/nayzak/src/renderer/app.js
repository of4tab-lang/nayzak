'use strict';

const api = window.nayzak;
const $ = (selector, root = document) => root.querySelector(selector);
const $$ = (selector, root = document) => [...root.querySelectorAll(selector)];

const UNIT_MS = { ms: 1, s: 1000, m: 60_000 };
const MAX_INTERVAL_MS = 86_400_000;
const isMac = navigator.platform.toLowerCase().includes('mac');
const params = new URLSearchParams(window.location.search);
const demoMode = params.get('demo') === '1';

const DEFAULT_FORMS = {
  single: {
    target: 'cursor',
    x: 960,
    y: 540,
    speed: 50,
    unit: 'ms',
    button: 'left',
    repeat: 'infinite',
    count: 100,
    delay: 3,
  },
  multi: {
    points: [],
    button: 'left',
    repeat: 'infinite',
    count: 5,
    seriesDelay: 500,
  },
  smart: {
    humanEnabled: true,
    interval: 150,
    variance: 35,
    jitter: 3,
    button: 'left',
    microEnabled: true,
    microEvery: 12,
    microMin: 180,
    microMax: 450,
    delay: 3,
    jiggleEnabled: true,
    jiggleInterval: 45,
    jiggleIdleOnly: true,
    timerEnabled: false,
    timerMinutes: 30,
    timerAction: 'stop',
  },
};

const state = {
  view: 'single',
  forms: structuredClone(DEFAULT_FORMS),
  prefs: { tray: true, autoLaunch: false, trayHintShown: false },
  hotkeys: { toggle: 'F8', panic: 'F9' },
  hotkeyStatus: {},
  engine: {
    running: false,
    mode: null,
    stopReason: null,
    clicks: 0,
    jiggles: 0,
    elapsedMs: 0,
    countdownMs: 0,
    timerRemainingMs: null,
    cps: 0,
    currentIndex: -1,
    error: null,
  },
  lastResults: { single: null, multi: null, smart: null },
  startError: null,
  lastStopSignature: null,
  lastActivePoint: -1,
  recordingHotkey: null,
  recordingLabels: [],
  hotkeyBusy: false,
  settingsOpen: false,
  busy: false,
  demo: demoMode,
  boot: null,
  cursor: null,
};

let saveTimer = null;
let toastTimer = null;
let cursorPreviewTimer = null;
let cursorPreviewBusy = false;

/* ───────────── small utilities ───────────── */
function clamp(value, min, max) {
  return Math.min(max, Math.max(min, value));
}

function integer(value, fallback, min, max) {
  const number = Number(value);
  if (!Number.isFinite(number)) return fallback;
  return clamp(Math.round(number), min, max);
}

function decimal(value, fallback, min, max) {
  const number = Number(value);
  if (!Number.isFinite(number)) return fallback;
  return clamp(number, min, max);
}

function oneOf(value, allowed, fallback) {
  return allowed.includes(value) ? value : fallback;
}

function bool(value, fallback) {
  return typeof value === 'boolean' ? value : fallback;
}

function makeId() {
  if (globalThis.crypto?.randomUUID) return globalThis.crypto.randomUUID();
  return `point-${Date.now()}-${Math.random().toString(36).slice(2)}`;
}

function fmtInt(value) {
  return new Intl.NumberFormat('en-US').format(Math.max(0, Math.round(Number(value) || 0)));
}

function fmtClock(ms) {
  const total = Math.max(0, Math.round((Number(ms) || 0) / 1000));
  const hours = Math.floor(total / 3600);
  const minutes = Math.floor((total % 3600) / 60);
  const seconds = total % 60;
  if (hours > 0) {
    return `${hours}:${String(minutes).padStart(2, '0')}:${String(seconds).padStart(2, '0')}`;
  }
  return `${String(minutes).padStart(2, '0')}:${String(seconds).padStart(2, '0')}`;
}

function fmtTimerDuration(minutes) {
  const mins = Math.max(1, Math.round(minutes));
  const hours = Math.floor(mins / 60);
  const rest = mins % 60;
  return `${String(hours).padStart(2, '0')}:${String(rest).padStart(2, '0')}:00`;
}

function fmtInterval(ms) {
  if (ms < 1000) return `${Math.round(ms)} ms`;
  if (ms < 60_000) {
    const value = ms / 1000;
    return `${Number.isInteger(value) ? value : value.toFixed(1)} ث`;
  }
  const value = ms / 60_000;
  return `${Number.isInteger(value) ? value : value.toFixed(1)} د`;
}

function fmtCps(intervalMs) {
  const cps = 1000 / Math.max(1, intervalMs);
  if (cps >= 100) return Math.round(cps).toString();
  if (cps >= 10) return cps.toFixed(1);
  return cps.toFixed(2);
}

function fmtSeconds(ms) {
  const seconds = ms / 1000;
  if (seconds === 0) return "أقل من ثانية";
  if (seconds < 10) return `${seconds.toFixed(1)} ثانية`;
  return `${Math.round(seconds)} ثانية`;
}

const BUTTON_LABELS = { left: 'يسار', middle: 'أوسط', right: 'يمين' };

function clicksLabel(value, grammaticalCase = 'nominative') {
  const count = Math.max(0, Math.round(Number(value) || 0));
  if (count === 0) return '0 نقرة';
  if (count === 1) return 'نقرة واحدة';
  if (count === 2) return grammaticalCase === 'accusative' ? 'نقرتين' : 'نقرتان';
  if (count <= 10) return `${fmtInt(count)} نقرات`;
  return `${fmtInt(count)} نقرة`;
}

function repeatLabel(repeat, count) {
  return repeat === 'count' ? clicksLabel(count) : 'بلا نهاية';
}

function setSeg(seg, value) {
  if (!seg) return;
  for (const button of $$('button[data-value]', seg)) {
    button.classList.toggle('is-active', button.dataset.value === value);
  }
}

function bindSeg(name, handler) {
  const seg = $(`[data-seg="${name}"]`);
  if (!seg) return;
  seg.addEventListener('click', (event) => {
    const button = event.target.closest('button[data-value]');
    if (!button || button.classList.contains('is-active')) return;
    setSeg(seg, button.dataset.value);
    handler(button.dataset.value);
  });
}

function setRangeFill(input) {
  const min = Number(input.min) || 0;
  const max = Number(input.max) || 100;
  const value = Number(input.value) || 0;
  const percent = max === min ? 0 : ((value - min) / (max - min)) * 100;
  input.style.setProperty('--p', `${percent}%`);
}

function toast(message, type = 'ok', timeout = 3800) {
  const stack = $('#toastStack');
  if (!stack || !message) return;

  if (stack.children.length >= 3) stack.firstElementChild?.remove();

  const element = document.createElement('div');
  element.className = `toast${type ? ` is-${type}` : ''}`;
  const iconId = type === 'error' ? 'i-alert' : type === 'warn' ? 'i-alert' : 'i-check';
  element.innerHTML = `<span class="toast-icon"><svg><use href="#${iconId}"></use></svg></span><span class="toast-message"></span>`;
  $('.toast-message', element).textContent = message;
  stack.appendChild(element);

  setTimeout(() => {
    element.classList.add('is-leaving');
    setTimeout(() => element.remove(), 260);
  }, timeout);
}

function shake(element) {
  if (!element) return;
  element.classList.remove('shake');
  void element.offsetWidth;
  element.classList.add('shake');
  setTimeout(() => element.classList.remove('shake'), 450);
}

/* ───────────── startup data ───────────── */
function normalizePoint(point, fallbackDelay = 300) {
  return {
    id: makeId(),
    x: integer(point?.x, 0, -100_000, 100_000),
    y: integer(point?.y, 0, -100_000, 100_000),
    delay: integer(point?.delay ?? point?.delayMs, fallbackDelay, 0, MAX_INTERVAL_MS),
  };
}

function loadForms(saved) {
  const forms = structuredClone(DEFAULT_FORMS);
  if (!saved || typeof saved !== 'object') return forms;

  const single = saved.single && typeof saved.single === 'object' ? saved.single : {};
  const multi = saved.multi && typeof saved.multi === 'object' ? saved.multi : {};
  const smart = saved.smart && typeof saved.smart === 'object' ? saved.smart : {};

  const singleUnit = oneOf(single.unit, ['ms', 's', 'm'], forms.single.unit);
  const maxSpeed = Math.max(1, Math.floor(MAX_INTERVAL_MS / UNIT_MS[singleUnit]));
  forms.single = {
    target: oneOf(single.target, ['cursor', 'fixed'], forms.single.target),
    x: integer(single.x, forms.single.x, -100_000, 100_000),
    y: integer(single.y, forms.single.y, -100_000, 100_000),
    speed: integer(single.speed, forms.single.speed, 1, maxSpeed),
    unit: singleUnit,
    button: oneOf(single.button, ['left', 'middle', 'right'], 'left'),
    repeat: oneOf(single.repeat, ['infinite', 'count'], 'infinite'),
    count: integer(single.count, forms.single.count, 1, 100_000_000),
    delay: integer(single.delay, forms.single.delay, 0, 10),
  };

  const savedPoints = Array.isArray(multi.points) ? multi.points.slice(0, 200) : [];
  forms.multi = {
    points: savedPoints.map((point) => normalizePoint(point)),
    button: oneOf(multi.button, ['left', 'middle', 'right'], 'left'),
    repeat: oneOf(multi.repeat, ['infinite', 'count'], 'infinite'),
    count: integer(multi.count, forms.multi.count, 1, 100_000_000),
    seriesDelay: integer(multi.seriesDelay, forms.multi.seriesDelay, 0, MAX_INTERVAL_MS),
  };

  const microMin = integer(smart.microMin, forms.smart.microMin, 20, 600_000);
  const microMax = integer(smart.microMax, forms.smart.microMax, 20, 600_000);
  forms.smart = {
    humanEnabled: bool(smart.humanEnabled, forms.smart.humanEnabled),
    interval: integer(smart.interval, forms.smart.interval, 1, 1_000_000),
    variance: integer(smart.variance, forms.smart.variance, 0, 80),
    jitter: integer(smart.jitter, forms.smart.jitter, 0, 30),
    button: oneOf(smart.button, ['left', 'middle', 'right'], 'left'),
    microEnabled: bool(smart.microEnabled, forms.smart.microEnabled),
    microEvery: integer(smart.microEvery, forms.smart.microEvery, 2, 10_000),
    microMin,
    microMax: Math.max(microMin, microMax),
    delay: integer(smart.delay, forms.smart.delay, 0, 10),
    jiggleEnabled: bool(smart.jiggleEnabled, forms.smart.jiggleEnabled),
    jiggleInterval: integer(smart.jiggleInterval, forms.smart.jiggleInterval, 1, 3600),
    jiggleIdleOnly: bool(smart.jiggleIdleOnly, forms.smart.jiggleIdleOnly),
    timerEnabled: bool(smart.timerEnabled, forms.smart.timerEnabled),
    timerMinutes: integer(smart.timerMinutes, forms.smart.timerMinutes, 1, 1440),
    timerAction: oneOf(smart.timerAction, ['stop', 'quit'], 'stop'),
  };

  return forms;
}

function serializeUi() {
  return {
    version: 1,
    tab: state.view,
    single: { ...state.forms.single },
    multi: {
      ...state.forms.multi,
      points: state.forms.multi.points.map(({ x, y, delay }) => ({ x, y, delay })),
    },
    smart: { ...state.forms.smart },
  };
}

function scheduleSave() {
  if (saveTimer) clearTimeout(saveTimer);
  saveTimer = setTimeout(() => {
    saveTimer = null;
    void api.saveUi(serializeUi());
  }, 220);
}

function saveNow() {
  if (saveTimer) {
    clearTimeout(saveTimer);
    saveTimer = null;
  }
  void api.saveUi(serializeUi());
}

/* ───────────── view navigation ───────────── */
function updateGlider() {
  const nav = $('#mainNav');
  const glider = $('#navGlider');
  const active = $('.nav-item.is-active', nav);
  if (!nav || !glider || !active) return;
  const navRect = nav.getBoundingClientRect();
  const rect = active.getBoundingClientRect();
  glider.style.width = `${rect.width}px`;
  glider.style.left = `${rect.left - navRect.left}px`;
}

function setView(view, { persist = true } = {}) {
  const resolved = oneOf(view, ['single', 'multi', 'smart'], 'single');
  state.view = resolved;
  document.body.dataset.view = resolved;

  $$('.view').forEach((panel) => {
    panel.classList.toggle('is-active', panel.dataset.viewPanel === resolved);
  });
  $$('.nav-item').forEach((item) => {
    const active = item.dataset.nav === resolved;
    item.classList.toggle('is-active', active);
    if (active) item.setAttribute('aria-current', 'page');
    else item.removeAttribute('aria-current');
  });

  requestAnimationFrame(updateGlider);
  if (persist) scheduleSave();
  updateEngineUI();
}

/* ───────────── hotkey display ───────────── */
function hotkeyTokens(accelerator) {
  if (!accelerator) return [];
  return String(accelerator)
    .split('+')
    .map((token) => token.trim())
    .filter(Boolean);
}

function displayToken(token) {
  if (isMac) {
    if (token === 'Command' || token === 'CommandOrControl') return '⌘';
    if (token === 'Control') return '⌃';
    if (token === 'Alt' || token === 'Option') return '⌥';
    if (token === 'Shift') return '⇧';
    if (token === 'Super') return '⌘';
  } else {
    if (token === 'Control' || token === 'CommandOrControl') return 'Ctrl';
    if (token === 'Alt' || token === 'Option') return 'Alt';
    if (token === 'Shift') return 'Shift';
    if (token === 'Command' || token === 'Super') return 'Win';
  }
  return token;
}

function hotkeyLabels(accelerator) {
  return hotkeyTokens(accelerator).map(displayToken);
}

function compactHotkey(accelerator) {
  const labels = hotkeyLabels(accelerator);
  return isMac ? labels.join('') : labels.join('+');
}

function renderKeycaps(container, labels) {
  if (!container) return;
  container.replaceChildren();
  if (!labels || labels.length === 0) {
    container.classList.add('is-empty');
    return;
  }
  container.classList.remove('is-empty');
  for (const label of labels) {
    const kbd = document.createElement('kbd');
    kbd.textContent = label;
    container.appendChild(kbd);
  }
}

function renderHotkeyKeycaps(container, accelerator) {
  renderKeycaps(container, hotkeyLabels(accelerator));
}

function renderHotkeyFields() {
  for (const which of ['toggle', 'panic']) {
    const field = document.getElementById(which === 'toggle' ? 'hotkeyToggle' : 'hotkeyPanic');
    if (!field) continue;
    const status = state.hotkeyStatus?.[which];
    const stateLabel = $('.hotkey-state', field);
    const recording = state.recordingHotkey === which;

    field.classList.toggle('is-recording', recording);
    field.classList.toggle('is-unregistered', !recording && Boolean(status && status.ok === false));

    if (recording) {
      renderKeycaps($('.hotkey-keys', field), state.recordingLabels);
      stateLabel.textContent = state.recordingLabels.length ? 'الآن' : 'اضغط';
      field.title = 'اضغط التركيبة الجديدة، أو Esc للإلغاء';
      continue;
    }

    renderHotkeyKeycaps($('.hotkey-keys', field), state.hotkeys[which]);
    stateLabel.textContent = status && status.ok === false ? 'متعطل' : 'تغيير';
    field.title =
      status && status.ok === false
        ? status.error || 'تعذر تسجيل هذا الاختصار'
        : 'انقر لتغيير الاختصار';
  }

  const toggleText = compactHotkey(state.hotkeys.toggle);
  const panicText = compactHotkey(state.hotkeys.panic);
  $$('[data-hotkey-display]').forEach((element) => {
    element.textContent = toggleText;
  });
  $$('[data-panic-display]').forEach((element) => {
    element.textContent = panicText;
  });
  const engineHotkey = $('#engineHotkey');
  if (engineHotkey) engineHotkey.textContent = toggleText;
}

/* ───────────── single mode ───────────── */
function maxSingleSpeed() {
  return Math.max(1, Math.floor(MAX_INTERVAL_MS / UNIT_MS[state.forms.single.unit]));
}

function singleIntervalMs() {
  return clamp(
    Math.round(state.forms.single.speed * UNIT_MS[state.forms.single.unit]),
    1,
    MAX_INTERVAL_MS,
  );
}

function hydrateSingle() {
  const form = state.forms.single;
  form.speed = clamp(Math.round(form.speed), 1, maxSingleSpeed());
  setSeg($('[data-seg="singleTarget"]'), form.target);
  setSeg($('[data-seg="singleUnit"]'), form.unit);
  setSeg($('[data-seg="singleButton"]'), form.button);
  setSeg($('[data-seg="singleRepeat"]'), form.repeat);

  $('#singleX').value = form.x;
  $('#singleY').value = form.y;
  $('#singleDelay').value = form.delay;
  $('#singleSpeed').value = form.speed;
  $('#singleSpeed').max = maxSingleSpeed();
  $('#singleCount').value = form.count;
  updateSingleComputed();
}

function updateTargetPreview() {
  const form = state.forms.single;
  const fixed = form.target === 'fixed';
  const point = fixed ? { x: form.x, y: form.y } : state.cursor || { x: form.x, y: form.y };
  const preview = $('#singleTargetPreview');
  if (!preview) return;

  preview.classList.toggle('is-fixed', fixed);
  $('#singleTargetMode').textContent = fixed ? 'هدف مثبت' : 'المؤشر الحي';
  $('#singleTargetReadout').textContent = `X ${Math.round(point.x)} · Y ${Math.round(point.y)}`;
}

async function pollCursorPreview() {
  if (
    cursorPreviewBusy ||
    document.hidden ||
    state.view !== 'single' ||
    state.settingsOpen ||
    state.forms.single.target !== 'cursor'
  ) {
    return;
  }

  cursorPreviewBusy = true;
  try {
    const point = await api.getCursor();
    if (point && Number.isFinite(point.x) && Number.isFinite(point.y)) {
      state.cursor = point;
      updateTargetPreview();
    }
  } catch {
    // Cursor preview is cosmetic; keep the last known position.
  } finally {
    cursorPreviewBusy = false;
  }
}

function startCursorPreview() {
  if (cursorPreviewTimer) return;
  cursorPreviewTimer = setInterval(pollCursorPreview, 500);
  window.addEventListener('focus', pollCursorPreview);
  pollCursorPreview();
}

function updateSingleComputed() {
  const form = state.forms.single;
  const coords = $('#singleCoords');
  const speedInput = $('#singleSpeed');
  const intervalMs = singleIntervalMs();

  coords.hidden = form.target !== 'fixed';
  $('#singleSpeedSuffix').textContent = form.unit === 'ms' ? 'ms' : form.unit === 's' ? 'ث' : 'د';
  if (document.activeElement !== speedInput) speedInput.value = form.speed;
  speedInput.max = maxSingleSpeed();

  $('#singleCps').textContent = fmtCps(intervalMs);
  const perSecond = 1000 / intervalMs;
  const perMinute = 60_000 / intervalMs;
  $('#singlePerSecond').textContent =
    perSecond >= 10 ? Math.round(perSecond).toLocaleString('en-US') : perSecond.toFixed(1);
  $('#singlePerMinute').textContent = Math.round(perMinute).toLocaleString('en-US');
  const cadence = clamp(Math.round(100 - Math.log10(intervalMs / 10) * 58), 12, 100);
  $('#singleCadenceFill').style.width = `${cadence}%`;
  $('#singleCadenceLabel').textContent =
    intervalMs <= 25
      ? 'سريع جدًا'
      : intervalMs <= 100
        ? 'سريع'
        : intervalMs <= 300
          ? 'متوازن'
          : intervalMs <= 800
            ? 'هادئ'
            : 'بطيء';
  $('#singleCountWrap').hidden = form.repeat !== 'count';
  setSeg($('[data-seg="singleTarget"]'), form.target);
  setSeg($('[data-seg="singleUnit"]'), form.unit);
  setSeg($('[data-seg="singleButton"]'), form.button);
  setSeg($('[data-seg="singleRepeat"]'), form.repeat);

  for (const preset of $$('#singlePresets .preset')) {
    preset.classList.toggle('is-active', Number(preset.dataset.ms) === intervalMs);
  }

  $('#singleTargetHint').textContent =
    form.target === 'fixed'
      ? 'سيتحرك المؤشر إلى الإحداثيات المحددة عند بدء التشغيل.'
      : 'سيُثبَّت موضع المؤشر بعد العد التنازلي، ولن يتبع حركة يدك.';

  const summary = `${fmtInterval(intervalMs)} · ${BUTTON_LABELS[form.button]} · ${repeatLabel(
    form.repeat,
    form.count,
  )}`;
  $('[data-run-panel="single"] .run-summary').textContent = summary;

  updateTargetPreview();
  updateEngineUI();
}

function bindSingle() {
  bindSeg('singleTarget', (value) => {
    state.forms.single.target = value;
    updateSingleComputed();
    scheduleSave();
    if (value === 'cursor') pollCursorPreview();
  });

  bindSeg('singleUnit', (value) => {
    const form = state.forms.single;
    const duration = form.speed * UNIT_MS[form.unit];
    form.unit = value;
    form.speed = Math.max(1, Math.round(duration / UNIT_MS[value]));
    const speedInput = $('#singleSpeed');
    speedInput.max = maxSingleSpeed();
    speedInput.value = form.speed;
    updateSingleComputed();
    scheduleSave();
  });

  bindSeg('singleButton', (value) => {
    state.forms.single.button = value;
    updateSingleComputed();
    scheduleSave();
  });

  bindSeg('singleRepeat', (value) => {
    state.forms.single.repeat = value;
    updateSingleComputed();
    scheduleSave();
  });

  bindNumeric($('#singleX'), -100_000, 100_000, (value) => {
    state.forms.single.x = value;
    updateTargetPreview();
    scheduleSave();
  });

  bindNumeric($('#singleY'), -100_000, 100_000, (value) => {
    state.forms.single.y = value;
    updateTargetPreview();
    scheduleSave();
  });

  bindNumeric($('#singleDelay'), 0, 10, (value) => {
    state.forms.single.delay = value;
    updateEngineUI();
    scheduleSave();
  });

  bindNumeric(
    $('#singleSpeed'),
    1,
    1_000_000,
    (value) => {
      state.forms.single.speed = value;
      updateSingleComputed();
      scheduleSave();
    },
    { live: true, minFn: () => 1, maxFn: maxSingleSpeed },
  );

  bindNumeric($('#singleCount'), 1, 100_000_000, (value) => {
    state.forms.single.count = value;
    updateSingleComputed();
    scheduleSave();
  });

  for (const preset of $$('#singlePresets .preset')) {
    preset.addEventListener('click', () => {
      const ms = Number(preset.dataset.ms);
      state.forms.single.unit = 'ms';
      state.forms.single.speed = ms;
      $('#singleSpeed').max = maxSingleSpeed();
      $('#singleSpeed').value = ms;
      updateSingleComputed();
      scheduleSave();
    });
  }

  $('#btnPickSingle').addEventListener('click', async () => {
    if (state.engine.running) {
      toast('أوقف التشغيل قبل التقاط إحداثيات جديدة.', 'warn');
      return;
    }
    const point = await api.capturePoint();
    if (!point) return;
    state.forms.single.target = 'fixed';
    state.forms.single.x = point.x;
    state.forms.single.y = point.y;
    $('#singleX').value = point.x;
    $('#singleY').value = point.y;
    updateSingleComputed();
    scheduleSave();
    toast(`تم التقاط الإحداثيات: ${point.x}, ${point.y}`, 'ok', 2600);
  });

  startCursorPreview();
}

/* ───────────── numeric inputs & steppers ───────────── */
function normalizeNumericInputs(root = document) {
  for (const input of $$('input[type="number"]', root)) {
    input.type = 'text';
    input.inputMode = 'numeric';
    input.autocomplete = 'off';
    input.spellcheck = false;
    input.lang = 'en';
    input.dir = 'ltr';
  }
}

function bindNumeric(input, min, max, apply, options = {}) {
  if (!input) return;
  const resolveMin = () => (options.minFn ? options.minFn() : min);
  const resolveMax = () => (options.maxFn ? options.maxFn() : max);

  const commit = () => {
    let value = Number(input.value);
    if (!Number.isFinite(value)) value = options.fallback ?? resolveMin();
    value = clamp(Math.round(value), resolveMin(), resolveMax());
    input.value = value;
    apply(value);
  };

  input.addEventListener('input', () => {
    const raw = Number(input.value);
    if (!Number.isFinite(raw) || input.value.trim() === '') return;
    if (options.live) apply(clamp(Math.round(raw), resolveMin(), resolveMax()));
  });

  input.addEventListener('change', commit);
  input.addEventListener('blur', () => {
    if (input.value.trim() === '') commit();
  });
}

function bindSteppers() {
  for (const stepper of $$('.stepper')) {
    const input = $('input', stepper);
    if (!input) continue;
    for (const button of $$('button[data-step]', stepper)) {
      button.addEventListener('click', () => {
        if (input.disabled) return;
        const min = Number(input.min) || 0;
        const max = Number(input.max) || 1_000_000;
        const step = Math.abs(Number(input.step) || 1) * (Number(button.dataset.step) || 1);
        const current = Number.isFinite(Number(input.value)) ? Number(input.value) : min;
        input.value = clamp(Math.round(current + step), min, max);
        input.dispatchEvent(new Event('input', { bubbles: true }));
        input.dispatchEvent(new Event('change', { bubbles: true }));
      });
    }
  }
}

/* ───────────── multi-point macro ───────────── */
const MAX_POINTS = 200;
const MAX_CYCLE_DOTS = 28;

function pointsLabel(count) {
  if (count === 0) return 'لا توجد نقاط';
  if (count === 1) return 'نقطة واحدة';
  if (count === 2) return 'نقطتان';
  if (count <= 10) return `${fmtInt(count)} نقاط`;
  return `${fmtInt(count)} نقطة`;
}

function totalCycleMs(form = state.forms.multi) {
  if (!form.points.length) return 0;
  return form.points.reduce((total, point) => total + point.delay, 0) + form.seriesDelay;
}

function findPointIndex(id) {
  return state.forms.multi.points.findIndex((point) => point.id === id);
}

function pointCoords(point) {
  return `${point.x}, ${point.y}`;
}

function renderMulti({ scrollToEnd = false } = {}) {
  const form = state.forms.multi;
  const empty = $('#multiEmpty');
  const wrap = $('#multiListWrap');
  const list = $('#multiList');
  if (!empty || !wrap || !list) return;

  const previousScroll = list.scrollTop;
  empty.hidden = form.points.length > 0;
  wrap.hidden = form.points.length === 0;
  list.replaceChildren();

  form.points.forEach((point, index) => {
    const row = document.createElement('li');
    row.className = 'point-row';
    row.dataset.pointId = point.id;
    row.innerHTML = `
      <span class="point-index">${String(index + 1).padStart(2, '0')}</span>
      <div class="point-coords">
        <label class="point-coord">
          <span>X</span>
          <input type="text" inputmode="numeric" data-field="x" value="${point.x}" min="-100000" max="100000" step="1" inputmode="numeric" aria-label="إحداثي X للنقطة ${index + 1}" />
        </label>
        <label class="point-coord">
          <span>Y</span>
          <input type="text" inputmode="numeric" data-field="y" value="${point.y}" min="-100000" max="100000" step="1" inputmode="numeric" aria-label="إحداثي Y للنقطة ${index + 1}" />
        </label>
      </div>
      <label class="point-delay" title="التأخير بعد هذه النقطة">
        <svg><use href="#i-clock"></use></svg>
        <input type="text" inputmode="numeric" data-field="delay" value="${point.delay}" min="0" max="86400000" step="50" inputmode="numeric" aria-label="تأخير النقطة ${index + 1} بالمللي ثانية" />
        <em>ms</em>
      </label>
      <div class="point-actions">
        <button type="button" data-action="up" aria-label="تحريك النقطة ${index + 1} للأعلى" title="أعلى" ${index === 0 ? 'disabled' : ''}>
          <svg><use href="#i-chevron-up"></use></svg>
        </button>
        <button type="button" data-action="down" aria-label="تحريك النقطة ${index + 1} للأسفل" title="أسفل" ${index === form.points.length - 1 ? 'disabled' : ''}>
          <svg><use href="#i-chevron-down"></use></svg>
        </button>
        <button type="button" class="danger" data-action="remove" aria-label="حذف النقطة ${index + 1}" title="حذف">
          <svg><use href="#i-trash"></use></svg>
        </button>
      </div>`;
    list.appendChild(row);
  });

  list.scrollTop = scrollToEnd ? list.scrollHeight : previousScroll;
  updateMultiComputed();
}

function updateCycleStrip() {
  const strip = $('#multiCycleStrip');
  if (!strip) return;
  const points = state.forms.multi.points;
  const dots = Math.min(points.length, MAX_CYCLE_DOTS);
  const signature = `${points.length}:${dots}`;

  if (strip.dataset.signature !== signature) {
    strip.replaceChildren();
    for (let index = 0; index < dots; index += 1) {
      const dot = document.createElement('span');
      dot.className = 'cycle-dot';
      dot.dataset.dot = String(index);
      strip.appendChild(dot);
    }
    strip.dataset.signature = signature;
  }

  updateMultiRunIndicators(
    state.engine.running && state.engine.mode === 'multi' ? state.engine : null,
  );
}

function updateMultiRunIndicators(engineState) {
  const rows = $$('#multiList .point-row');
  const activeIndex = engineState && engineState.currentIndex >= 0 ? engineState.currentIndex : -1;

  rows.forEach((row, index) => {
    row.classList.toggle('is-current', index === activeIndex);
  });

  const pointsCount = state.forms.multi.points.length;
  const dots = $$('#multiCycleStrip .cycle-dot');
  const activeDot =
    activeIndex >= 0 && pointsCount > 0
      ? Math.min(dots.length - 1, Math.floor((activeIndex / pointsCount) * dots.length))
      : -1;
  dots.forEach((dot, index) => dot.classList.toggle('is-current', index === activeDot));

  if (activeIndex >= 0 && activeIndex !== state.lastActivePoint && state.view === 'multi') {
    const list = $('#multiList');
    const row = rows[activeIndex];
    if (list && row) {
      const listRect = list.getBoundingClientRect();
      const rowRect = row.getBoundingClientRect();
      if (rowRect.top < listRect.top) list.scrollTop -= listRect.top - rowRect.top + 8;
      else if (rowRect.bottom > listRect.bottom) list.scrollTop += rowRect.bottom - listRect.bottom + 8;
    }
  }
  state.lastActivePoint = activeIndex;
}

function updateMultiLock() {
  const form = state.forms.multi;
  const locked = state.engine.running || state.busy;
  const atLimit = form.points.length >= MAX_POINTS;
  const addButton = $('#btnAddPoint');
  const captureButton = $('#btnCapturePoint');
  const captureFirst = $('#btnCaptureFirst');
  if (addButton) addButton.disabled = locked || atLimit;
  if (captureButton) captureButton.disabled = locked || atLimit;
  if (captureFirst) captureFirst.disabled = locked || atLimit;

  $$('#multiList .point-row').forEach((row, index) => {
    const pointId = row.dataset.pointId;
    for (const input of $$('input', row)) input.disabled = locked;
    for (const button of $$('button[data-action]', row)) {
      const action = button.dataset.action;
      let disabled = locked;
      if (action === 'up' && index === 0) disabled = true;
      if (action === 'down' && index === form.points.length - 1) disabled = true;
      button.disabled = disabled;
    }
    row.dataset.pointId = pointId;
  });
}

function updateMultiComputed() {
  const form = state.forms.multi;
  setSeg($('[data-seg="multiButton"]'), form.button);
  setSeg($('[data-seg="multiRepeat"]'), form.repeat);

  const countWrap = $('#multiCountWrap');
  const countInput = $('#multiCount');
  const seriesInput = $('#multiSeriesDelay');
  if (countWrap) countWrap.hidden = form.repeat !== 'count';
  if (countInput && document.activeElement !== countInput) countInput.value = form.count;
  if (seriesInput && document.activeElement !== seriesInput) seriesInput.value = form.seriesDelay;

  const cycleMs = totalCycleMs();
  const count = form.points.length;
  const summary = $('#multiSummary');
  if (summary) {
    summary.textContent = count === 0 ? 'لا توجد نقاط بعد' : `${pointsLabel(count)} · ${fmtSeconds(cycleMs)} / دورة`;
  }

  const total = $('#multiTotal');
  const cycle = $('#multiCycleTime');
  if (total) total.textContent = pointsLabel(count);
  if (cycle) {
    cycle.textContent =
      count === 0 ? '0 ثانية / دورة' : `${fmtSeconds(cycleMs)} / دورة`;
  }

  $('[data-run-panel="multi"] .run-summary').textContent =
    count === 0
      ? 'لا توجد نقاط · أضف نقطة للبدء'
      : `${pointsLabel(count)} · ${BUTTON_LABELS[form.button]} · ${repeatLabel(form.repeat, form.count)}`;

  updateCycleStrip();
  updateMultiLock();
  updateEngineUI();
}

async function appendMultiPoint(point, label = 'أضيفت النقطة') {
  if (state.engine.running) {
    toast('أوقف التشغيل قبل تعديل نقاط المسار.', 'warn');
    return null;
  }
  if (state.busy) return null;
  if (state.forms.multi.points.length >= MAX_POINTS) {
    toast(`الحد الأقصى ${MAX_POINTS} نقطة في المسار.`, 'warn');
    return null;
  }

  const normalized = normalizePoint(point);
  state.forms.multi.points.push(normalized);
  renderMulti({ scrollToEnd: true });
  scheduleSave();
  toast(`${label}: ${pointCoords(normalized)}`, 'ok', 2400);
  return normalized;
}

async function addPointAtCursor() {
  if (state.engine.running || state.busy) {
    toast('أوقف التشغيل قبل تعديل نقاط المسار.', 'warn');
    return;
  }
  let cursor = null;
  try {
    cursor = await api.getCursor();
  } catch {
    cursor = null;
  }
  const fallback = state.forms.multi.points.at(-1) || {
    x: state.forms.single.x,
    y: state.forms.single.y,
  };
  await appendMultiPoint(
    cursor || { x: fallback.x + 50, y: fallback.y + 50, delay: 300 },
    'أضيفت نقطة',
  );
}

async function captureMultiPoint() {
  if (state.engine.running || state.busy) {
    toast('أوقف التشغيل قبل التقاط نقطة جديدة.', 'warn');
    return;
  }
  if (state.forms.multi.points.length >= MAX_POINTS) {
    toast(`الحد الأقصى ${MAX_POINTS} نقطة في المسار.`, 'warn');
    return;
  }
  const point = await api.capturePoint();
  if (!point) return;
  await appendMultiPoint(point, 'تم التقاط النقطة');
}

function bindMulti() {
  bindSeg('multiButton', (value) => {
    state.forms.multi.button = value;
    updateMultiComputed();
    scheduleSave();
  });

  bindSeg('multiRepeat', (value) => {
    state.forms.multi.repeat = value;
    updateMultiComputed();
    scheduleSave();
  });

  bindNumeric($('#multiCount'), 1, 100_000_000, (value) => {
    state.forms.multi.count = value;
    updateMultiComputed();
    scheduleSave();
  }, { fallback: 5 });

  bindNumeric($('#multiSeriesDelay'), 0, MAX_INTERVAL_MS, (value) => {
    state.forms.multi.seriesDelay = value;
    updateMultiComputed();
    scheduleSave();
  }, { fallback: 500 });

  for (const id of ['btnAddPoint', 'btnCaptureFirst']) {
    $(`#${id}`)?.addEventListener('click', addPointAtCursor);
  }
  for (const id of ['btnCapturePoint']) {
    $(`#${id}`)?.addEventListener('click', captureMultiPoint);
  }

  const list = $('#multiList');
  if (!list) return;

  list.addEventListener('input', (event) => {
    const input = event.target.closest('input[data-field]');
    if (!input) return;
    const row = input.closest('.point-row');
    const index = findPointIndex(row?.dataset.pointId);
    if (index < 0) return;
    const point = state.forms.multi.points[index];
    const raw = input.value;
    if (raw.trim() === '') return;
    const value = Number(raw);
    if (!Number.isFinite(value)) return;

    if (input.dataset.field === 'delay') {
      point.delay = clamp(Math.round(value), 0, MAX_INTERVAL_MS);
    } else {
      point[input.dataset.field] = clamp(Math.round(value), -100_000, 100_000);
    }
    updateMultiComputed();
    scheduleSave();
  });

  list.addEventListener('change', (event) => {
    const input = event.target.closest('input[data-field]');
    if (!input) return;
    const row = input.closest('.point-row');
    const index = findPointIndex(row?.dataset.pointId);
    if (index < 0) return;
    const point = state.forms.multi.points[index];
    const field = input.dataset.field;
    let value = Number(input.value);
    if (!Number.isFinite(value)) value = point[field];
    value = field === 'delay'
      ? clamp(Math.round(value), 0, MAX_INTERVAL_MS)
      : clamp(Math.round(value), -100_000, 100_000);
    point[field] = value;
    input.value = value;
    updateMultiComputed();
    scheduleSave();
  });

  list.addEventListener('click', (event) => {
    const button = event.target.closest('button[data-action]');
    if (!button || button.disabled) return;
    if (state.engine.running || state.busy) {
      toast('أوقف التشغيل قبل تعديل نقاط المسار.', 'warn');
      return;
    }
    const row = button.closest('.point-row');
    const index = findPointIndex(row?.dataset.pointId);
    if (index < 0) return;

    const action = button.dataset.action;
    if (action === 'up' && index > 0) {
      const [point] = state.forms.multi.points.splice(index, 1);
      state.forms.multi.points.splice(index - 1, 0, point);
      renderMulti();
      scheduleSave();
      return;
    }
    if (action === 'down' && index < state.forms.multi.points.length - 1) {
      const [point] = state.forms.multi.points.splice(index, 1);
      state.forms.multi.points.splice(index + 1, 0, point);
      renderMulti();
      scheduleSave();
      return;
    }
    if (action === 'remove') {
      state.forms.multi.points.splice(index, 1);
      renderMulti();
      scheduleSave();
      toast('تم حذف النقطة.', 'ok', 1800);
    }
  });
}

/* ───────────── smart / anti-AFK ───────────── */
function smartSummaryText() {
  const form = state.forms.smart;
  const parts = [];
  parts.push(form.humanEnabled ? 'نقر بشري' : 'نقر متوقف');
  parts.push(form.jiggleEnabled ? 'مانع خمول' : 'بلا مانع خمول');
  parts.push(form.timerEnabled ? `مؤقت ${fmtInt(form.timerMinutes)} د` : 'بلا مؤقت');
  return parts.join(' · ');
}

function updateSmartComputed() {
  const form = state.forms.smart;
  const humanBody = $('#smartHumanBody');
  const microPause = $('.micro-pause');
  const timerBody = $('#smartTimerBody');
  const jiggleBody = $('#smartJiggleEnabled')?.closest('.utility-card')?.querySelector('.utility-body');

  setSeg($('[data-seg="smartButton"]'), form.button);
  setSeg($('[data-seg="smartTimerAction"]'), form.timerAction);

  const humanSwitch = $('#smartHumanEnabled');
  const microSwitch = $('#smartMicroEnabled');
  const jiggleSwitch = $('#smartJiggleEnabled');
  const idleSwitch = $('#smartJiggleIdleOnly');
  const timerSwitch = $('#smartTimerEnabled');
  if (humanSwitch) humanSwitch.checked = form.humanEnabled;
  if (microSwitch) microSwitch.checked = form.microEnabled;
  if (jiggleSwitch) jiggleSwitch.checked = form.jiggleEnabled;
  if (idleSwitch) idleSwitch.checked = form.jiggleIdleOnly;
  if (timerSwitch) timerSwitch.checked = form.timerEnabled;

  humanBody?.classList.toggle('is-disabled', !form.humanEnabled);
  microPause?.classList.toggle('is-disabled', !form.microEnabled);
  timerBody?.classList.toggle('is-disabled', !form.timerEnabled);
  jiggleBody?.classList.toggle('is-disabled', !form.jiggleEnabled);

  const intervalInput = $('#smartInterval');
  const delayInput = $('#smartDelay');
  const microEvery = $('#smartMicroEvery');
  const microMin = $('#smartMicroMin');
  const microMax = $('#smartMicroMax');
  const jiggleInterval = $('#smartJiggleInterval');
  const timerMinutes = $('#smartTimerMinutes');
  if (intervalInput && document.activeElement !== intervalInput) intervalInput.value = form.interval;
  if (delayInput && document.activeElement !== delayInput) delayInput.value = form.delay;
  if (microEvery && document.activeElement !== microEvery) microEvery.value = form.microEvery;
  if (microMin && document.activeElement !== microMin) microMin.value = form.microMin;
  if (microMax && document.activeElement !== microMax) microMax.value = form.microMax;
  if (jiggleInterval && document.activeElement !== jiggleInterval) jiggleInterval.value = form.jiggleInterval;
  if (timerMinutes && document.activeElement !== timerMinutes) timerMinutes.value = form.timerMinutes;

  const variance = $('#smartVariance');
  const jitter = $('#smartJitter');
  if (variance) {
    variance.value = form.variance;
    setRangeFill(variance);
  }
  if (jitter) {
    jitter.value = form.jitter;
    setRangeFill(jitter);
  }
  const varianceValue = $('#smartVarianceValue');
  const jitterValue = $('#smartJitterValue');
  if (varianceValue) varianceValue.textContent = form.variance;
  if (jitterValue) jitterValue.textContent = form.jitter;

  const readout = $('#smartTimerReadout');
  if (readout) {
    const label = $('span', readout);
    const value = $('b', readout);
    const isLive =
      state.engine.running &&
      state.engine.mode === 'smart' &&
      state.engine.timerRemainingMs !== null;
    if (label) label.textContent = isLive ? 'متبقي' : 'مدة الجلسة';
    if (value) {
      value.textContent = isLive
        ? fmtClock(state.engine.timerRemainingMs)
        : fmtTimerDuration(form.timerMinutes);
    }
    readout.classList.toggle('is-live', Boolean(isLive));
  }

  $('[data-run-panel="smart"] .run-summary').textContent = smartSummaryText();
  updateEngineUI();
}

function bindSmart() {
  bindSeg('smartButton', (value) => {
    state.forms.smart.button = value;
    updateSmartComputed();
    scheduleSave();
  });

  bindSeg('smartTimerAction', (value) => {
    state.forms.smart.timerAction = value;
    updateSmartComputed();
    scheduleSave();
  });

  const switches = [
    ['smartHumanEnabled', 'humanEnabled'],
    ['smartMicroEnabled', 'microEnabled'],
    ['smartJiggleEnabled', 'jiggleEnabled'],
    ['smartJiggleIdleOnly', 'jiggleIdleOnly'],
    ['smartTimerEnabled', 'timerEnabled'],
  ];
  for (const [id, key] of switches) {
    $(`#${id}`)?.addEventListener('change', (event) => {
      state.forms.smart[key] = event.target.checked;
      updateSmartComputed();
      scheduleSave();
    });
  }

  bindNumeric($('#smartInterval'), 1, 1_000_000, (value) => {
    state.forms.smart.interval = value;
    updateSmartComputed();
    scheduleSave();
  }, { fallback: 150 });

  bindNumeric($('#smartDelay'), 0, 10, (value) => {
    state.forms.smart.delay = value;
    updateSmartComputed();
    scheduleSave();
  }, { fallback: 3 });

  bindNumeric($('#smartMicroEvery'), 2, 10_000, (value) => {
    state.forms.smart.microEvery = value;
    updateSmartComputed();
    scheduleSave();
  }, { fallback: 12 });

  bindNumeric($('#smartMicroMin'), 20, 600_000, (value) => {
    state.forms.smart.microMin = value;
    if (state.forms.smart.microMax < value) state.forms.smart.microMax = value;
    updateSmartComputed();
    scheduleSave();
  }, { fallback: 180 });

  bindNumeric($('#smartMicroMax'), 20, 600_000, (value) => {
    state.forms.smart.microMax = Math.max(value, state.forms.smart.microMin);
    const maxInput = $('#smartMicroMax');
    if (maxInput) maxInput.value = state.forms.smart.microMax;
    updateSmartComputed();
    scheduleSave();
  }, { fallback: 450 });

  bindNumeric($('#smartJiggleInterval'), 1, 3600, (value) => {
    state.forms.smart.jiggleInterval = value;
    updateSmartComputed();
    scheduleSave();
  }, { fallback: 45 });

  bindNumeric($('#smartTimerMinutes'), 1, 1440, (value) => {
    state.forms.smart.timerMinutes = value;
    updateSmartComputed();
    scheduleSave();
  }, { fallback: 30 });

  const variance = $('#smartVariance');
  variance?.addEventListener('input', () => {
    state.forms.smart.variance = integer(variance.value, 35, 0, 80);
    updateSmartComputed();
    scheduleSave();
  });

  const jitter = $('#smartJitter');
  jitter?.addEventListener('input', () => {
    state.forms.smart.jitter = integer(jitter.value, 3, 0, 30);
    updateSmartComputed();
    scheduleSave();
  });
}

/* ───────────── engine orchestration ───────────── */
const MODE_NAMES = { single: 'SINGLE', multi: 'MACRO', smart: 'SMART' };
const MODE_SUBS = { single: 'START', multi: 'RUN MACRO', smart: 'GO SMART' };
const MODE_START_MESSAGES = {
  single: 'بدأ النقر المتكرر.',
  multi: 'بدأ تنفيذ المسار.',
  smart: 'بدأت الجلسة الذكية.',
};

function emptyEngineForMode(mode) {
  return {
    running: false,
    mode,
    stopReason: null,
    clicks: 0,
    jiggles: 0,
    elapsedMs: 0,
    countdownMs: 0,
    timerRemainingMs: null,
    cps: 0,
    currentIndex: -1,
    error: null,
  };
}

function buildConfig(mode) {
  const form = state.forms[mode];
  if (!form) throw new Error('وضع تشغيل غير معروف');

  if (mode === 'single') {
    const intervalMs = singleIntervalMs();
    if (!Number.isFinite(intervalMs) || intervalMs < 1) {
      throw new Error('حدد فاصلًا زمنيًا صالحًا أكبر من صفر');
    }
    return {
      target:
        form.target === 'fixed'
          ? { mode: 'fixed', x: Math.round(form.x), y: Math.round(form.y) }
          : { mode: 'cursor' },
      intervalMs,
      button: form.button,
      repeat: { mode: form.repeat, count: form.count },
      startDelayMs: form.delay * 1000,
    };
  }

  if (mode === 'multi') {
    if (form.points.length === 0) {
      throw new Error('أضف نقطة واحدة على الأقل إلى المسار قبل التشغيل');
    }
    return {
      points: form.points.map((point) => ({
        x: Math.round(point.x),
        y: Math.round(point.y),
        delayMs: Math.round(point.delay),
      })),
      button: form.button,
      repeat: { mode: form.repeat, count: form.count },
      seriesDelayMs: Math.round(form.seriesDelay),
      startDelayMs: 0,
    };
  }

  if (!form.humanEnabled && !form.jiggleEnabled) {
    throw new Error('فعّل النقر البشري أو مانع الخمول أولًا');
  }

  return {
    click: {
      enabled: form.humanEnabled,
      intervalMs: Math.max(1, Math.round(form.interval)),
      variancePct: Math.round(form.variance),
      jitterPx: Math.round(form.jitter),
      button: form.button,
      microPause: {
        enabled: form.microEnabled,
        every: Math.round(form.microEvery),
        minMs: Math.round(form.microMin),
        maxMs: Math.max(form.microMin, form.microMax),
      },
    },
    jiggle: {
      enabled: form.jiggleEnabled,
      intervalSec: Math.round(form.jiggleInterval),
      idleOnly: form.jiggleIdleOnly,
    },
    timer: {
      enabled: form.timerEnabled,
      minutes: Math.round(form.timerMinutes),
      action: form.timerAction,
    },
    startDelayMs: form.humanEnabled ? form.delay * 1000 : 0,
  };
}

function idleRunCopy(mode) {
  if (mode === 'single') {
    return {
      title: 'جاهز للانطلاق',
      hint: 'اضغط ابدأ أو استخدم الاختصار من أي تطبيق.',
    };
  }
  if (mode === 'multi') {
    return state.forms.multi.points.length
      ? {
          title: 'المسار جاهز',
          hint: 'اضغط ابدأ لتنفيذ النقاط بالترتيب والتأخير المحدد.',
        }
      : {
          title: 'المسار بانتظار النقاط',
          hint: 'التقط أول نقطة أو أضفها يدويًا لبدء بناء الماكرو.',
        };
  }
  return {
    title: 'جاهز للحماية',
    hint: 'فعّل ما تحتاجه ثم ابدأ الجلسة.',
  };
}

function activeRunCopy(mode, engineState) {
  if (mode === 'single') {
    return {
      title: 'جارٍ النقر الآن',
      hint: `النقر مستمر بمعدل ${fmtCps(singleIntervalMs())} في الثانية. استخدم الإيقاف أو الاختصار للتوقف.`,
    };
  }
  if (mode === 'multi') {
    const total = state.forms.multi.points.length;
    const index = engineState.currentIndex >= 0 ? engineState.currentIndex + 1 : 0;
    return {
      title: 'المسار قيد التنفيذ',
      hint: index > 0 ? `يجري النقر على النقطة ${index} من ${total}.` : 'يجري الانتقال إلى أول نقطة.',
    };
  }
  const form = state.forms.smart;
  const parts = [];
  if (form.humanEnabled) parts.push('نقر بشري');
  if (form.jiggleEnabled) parts.push('مانع خمول');
  return {
    title: 'الحماية مفعّلة',
    hint: `${parts.join(' + ')} يعمل الآن${form.timerEnabled ? ' حتى نهاية المؤقت.' : '.'}`,
  };
}

function stoppedRunCopy(mode, result) {
  const clickCount = Math.max(0, Math.round(Number(result.clicks) || 0));
  const duration = fmtClock(result.elapsedMs || 0);
  if (result.stopReason === 'error') {
    return {
      title: 'توقفت العملية',
      hint: result.error?.message || 'تعذر متابعة التنفيذ. راجع الصلاحيات ثم حاول مجددًا.',
    };
  }
  if (result.stopReason === 'timer') {
    return {
      title: 'انتهى المؤقت',
      hint: `تم إنهاء الجلسة تلقائيًا بعد ${duration}${clickCount ? ` و${clicksLabel(clickCount, 'accusative')}` : ''}.`,
    };
  }
  if (result.stopReason === 'panic') {
    return {
      title: 'إيقاف طارئ',
      hint: `أُوقفت الجلسة فورًا بعد ${clicksLabel(clickCount, 'accusative')}.`,
    };
  }
  if (result.stopReason === 'complete') {
    return {
      title: 'اكتملت الجلسة',
      hint:
        mode === 'smart' && !clickCount
          ? `اكتملت الجلسة بعد ${duration}.`
          : `تم تنفيذ ${clicksLabel(clickCount, 'accusative')} خلال ${duration}.`,
    };
  }
  return {
    title: 'تم الإيقاف',
    hint: `توقفت الجلسة بعد ${clicksLabel(clickCount, 'accusative')} خلال ${duration}.`,
  };
}

function fmtRate(value) {
  const number = Math.max(0, Number(value) || 0);
  if (number >= 100) return String(Math.round(number));
  if (number >= 10) return number.toFixed(1).replace(/\.0$/, '');
  return number.toFixed(2).replace(/0+$/, '').replace(/\.$/, '');
}

function updateRunStats(mode, engineState, isActive) {
  const panel = $(`[data-run-panel="${mode}"]`);
  if (!panel) return;
  const data = engineState || emptyEngineForMode(mode);
  const set = (key, value) => {
    const element = $(`[data-stat="${key}"]`, panel);
    if (element) element.textContent = value;
  };

  set('clicks', fmtInt(data.clicks || 0));
  set('elapsed', fmtClock(data.elapsedMs || 0));

  if (mode === 'single') {
    set('cps', fmtRate(data.cps || 0));
  } else if (mode === 'multi') {
    const total = state.forms.multi.points.length;
    const point =
      isActive && data.currentIndex >= 0
        ? `${data.currentIndex + 1} / ${Math.max(total, 1)}`
        : !isActive && data.currentIndex >= 0 && total > 0
          ? `${Math.min(data.currentIndex + 1, total)} / ${total}`
          : '—';
    set('point', point);
  } else {
    set('jiggles', fmtInt(data.jiggles || 0));
    set('timer', data.timerRemainingMs !== null && data.timerRemainingMs !== undefined
      ? fmtClock(data.timerRemainingMs)
      : '—');
  }
}

function updateModeRunPanel(mode) {
  const panel = $(`[data-run-panel="${mode}"]`);
  if (!panel) return;
  const engineState = state.engine;
  const isActive = Boolean(engineState.running && engineState.mode === mode);
  const isCounting = isActive && engineState.countdownMs > 0;
  const result = state.lastResults[mode] || null;
  const startError = state.startError?.mode === mode ? state.startError : null;
  const hasError = Boolean(startError || (!isActive && result?.stopReason === 'error'));
  const showResult = Boolean(!isActive && result);
  const displayState = isActive ? engineState : result;

  panel.classList.toggle('is-running', isActive && !isCounting);
  panel.classList.toggle('is-counting', isCounting);
  panel.classList.toggle('is-error', !isActive && hasError);

  let badge = 'READY';
  if (isCounting) badge = 'HOLD';
  else if (isActive) badge = 'LIVE';
  else if (hasError) badge = 'ERROR';
  else if (showResult) badge = 'DONE';

  const badgeElement = $('[data-run-badge]', panel);
  if (badgeElement) badgeElement.textContent = badge;

  const modeLabel = $('.run-mode [dir="ltr"]', panel);
  if (modeLabel) modeLabel.textContent = `${MODE_NAMES[mode]} · ${badge}`;

  const runButton = $('[data-run]', panel);
  const label = $('[data-run-label]', panel);
  const sub = $('[data-run-sub]', panel);
  if (runButton) runButton.disabled = state.busy;
  if (label) {
    label.textContent = isCounting
      ? String(Math.max(1, Math.ceil(engineState.countdownMs / 1000)))
      : isActive
        ? 'إيقاف'
        : 'ابدأ';
  }
  if (sub) sub.textContent = isCounting ? 'استعد' : isActive ? 'STOP' : MODE_SUBS[mode];
  if (runButton) {
    runButton.setAttribute(
      'aria-label',
      isActive ? 'إيقاف العملية الحالية' : `بدء وضع ${MODE_NAMES[mode]}`,
    );
  }

  const title = $('[data-run-title]', panel);
  const hint = $('[data-run-hint]', panel);
  let copy;
  if (isCounting) {
    copy = {
      title: 'استعد للبدء',
      hint: `انتقل إلى النافذة المستهدفة. يبدأ التنفيذ خلال ${Math.ceil(
        engineState.countdownMs / 1000,
      )} ثانية، ويمكنك الإلغاء بالضغط على الزر.`,
    };
  } else if (isActive) {
    copy = activeRunCopy(mode, engineState);
  } else if (startError) {
    copy = { title: 'تعذّر بدء التشغيل', hint: startError.message };
  } else if (showResult) {
    copy = stoppedRunCopy(mode, result);
  } else {
    copy = idleRunCopy(mode);
  }
  if (title) title.textContent = copy.title;
  if (hint) hint.textContent = copy.hint;

  updateRunStats(mode, displayState, isActive);
}

function updateSmartTimerReadout() {
  const readout = $('#smartTimerReadout');
  if (!readout) return;
  const label = $('span', readout);
  const value = $('b', readout);
  const activeTimer =
    state.engine.running &&
    state.engine.mode === 'smart' &&
    state.engine.timerRemainingMs !== null &&
    state.engine.timerRemainingMs !== undefined;
  if (label) label.textContent = activeTimer ? 'متبقي' : 'مدة الجلسة';
  if (value) {
    value.textContent = activeTimer
      ? fmtClock(state.engine.timerRemainingMs)
      : fmtTimerDuration(state.forms.smart.timerMinutes);
  }
  readout.classList.toggle('is-live', Boolean(activeTimer));
}

function updateEngineUI() {
  const engineState = state.engine;
  const activeMode = engineState.running ? engineState.mode : null;

  $$('.nav-item').forEach((item) => {
    item.classList.toggle('has-activity', item.dataset.nav === activeMode);
  });

  for (const mode of ['single', 'multi', 'smart']) {
    updateModeRunPanel(mode);
  }

  updateSmartTimerReadout();
  updateMultiLock();
  updateMultiRunIndicators(
    engineState.running && engineState.mode === 'multi' ? engineState : null,
  );

  const pill = $('#enginePill');
  const text = $('#engineText');
  if (!pill || !text) return;

  let pillState = 'idle';
  let pillText = 'جاهز';
  if (state.startError && !engineState.running) {
    pillState = 'error';
    pillText = 'تعذر التشغيل';
  } else if (engineState.running && engineState.countdownMs > 0) {
    pillState = 'countdown';
    pillText = `خلال ${Math.max(1, Math.ceil(engineState.countdownMs / 1000))} ث`;
  } else if (engineState.running) {
    pillState = 'running';
    pillText =
      engineState.mode === 'multi'
        ? 'المسار يعمل'
        : engineState.mode === 'smart'
          ? 'الحماية مفعّلة'
          : 'النقر مستمر';
  } else if (engineState.mode) {
    const result = state.lastResults[engineState.mode];
    if (result?.stopReason === 'error') {
      pillState = 'error';
      pillText = 'توقفت العملية';
    } else {
      pillText = 'متوقف';
    }
  }
  pill.dataset.state = pillState;
  text.textContent = pillText;
  pill.title =
    pillState === 'error'
      ? state.startError?.message || state.lastResults[engineState.mode]?.error?.message || 'حدث خطأ'
      : pillText;
}

function notifyStopResult(result) {
  if (!result || !result.stopReason) return;
  if (!['complete', 'timer', 'panic', 'error'].includes(result.stopReason)) return;

  const signature = `${result.mode}:${result.stopReason}:${result.clicks}:${result.elapsedMs}`;
  if (signature === state.lastStopSignature) return;
  state.lastStopSignature = signature;

  if (result.stopReason === 'complete') {
    toast(`اكتملت الجلسة · ${fmtInt(result.clicks || 0)} نقرة`, 'ok', 4200);
  } else if (result.stopReason === 'timer') {
    toast('انتهى المؤقت وتم إيقاف العملية.', 'warn', 4600);
  } else if (result.stopReason === 'panic') {
    toast('تم تنفيذ الإيقاف الطارئ.', 'warn', 3600);
  } else {
    toast(result.error?.message || 'توقفت العملية بسبب خطأ.', 'error', 5200);
  }
}

function handleEngineState(next) {
  if (!next || typeof next !== 'object') return;
  const previous = state.engine;
  const wasRunning = previous.running;
  const merged = { ...previous, ...next };

  if (merged.running) {
    state.startError = null;
    state.lastStopSignature = null;
  }

  state.engine = merged;

  if (wasRunning && !merged.running && merged.mode) {
    state.lastResults[merged.mode] = { ...merged };
    notifyStopResult(merged);
  }

  updateEngineUI();
}

function showStartError(mode, message, code) {
  state.startError = { mode, message: message || 'تعذر بدء التشغيل.' };
  if (code === 'ACCESSIBILITY') {
    const banner = $('#accessBanner');
    if (banner) banner.hidden = false;
  }
  const panel = $(`[data-run-panel="${mode}"]`);
  shake(panel?.querySelector('.run-button'));
  toast(state.startError.message, 'error', 5200);
  updateEngineUI();
}

async function startEngine(mode) {
  if (state.busy) return;
  if (state.engine.running) {
    if (state.engine.mode === mode) {
      await stopEngine();
    } else {
      toast('يوجد تشغيل نشط. أوقفه أولًا قبل بدء وضع آخر.', 'warn', 3800);
    }
    return;
  }

  let config;
  try {
    config = buildConfig(mode);
  } catch (error) {
    showStartError(mode, error?.message || 'تعذر تجهيز إعدادات التشغيل.');
    return;
  }

  saveNow();
  state.busy = true;
  state.startError = null;
  updateEngineUI();

  let result;
  try {
    result = await api.start(mode, config);
  } catch (error) {
    result = { ok: false, error: error?.message || 'تعذر الاتصال بمحرك النقر.' };
  }

  state.busy = false;
  if (result?.ok) {
    state.startError = null;
    if (result.state) handleEngineState(result.state);
    else updateEngineUI();
    toast(MODE_START_MESSAGES[mode] || 'بدأ التشغيل.', 'ok', 2300);
  } else {
    showStartError(mode, result?.error || 'تعذر بدء التشغيل.', result?.code);
  }
}

async function stopEngine({ silent = false } = {}) {
  if (state.busy) return;
  if (!state.engine.running) {
    if (!silent) toast('لا توجد عملية جارية الآن.', 'warn', 2400);
    return;
  }

  state.busy = true;
  updateEngineUI();
  let result;
  try {
    result = await api.stop();
  } catch (error) {
    result = { ok: false, error: error?.message || 'تعذر إيقاف المحرك.' };
  }
  state.busy = false;

  if (result?.state) handleEngineState(result.state);
  else updateEngineUI();

  if (!result?.ok && !silent) {
    toast(result?.error || 'تعذر إيقاف العملية.', 'error');
  }
}

async function panicStop() {
  if (!state.engine.running) {
    toast('لا توجد عملية جارية الآن.', 'warn', 2200);
    return;
  }
  try {
    const result = await api.stop();
    if (result?.state) handleEngineState(result.state);
  } catch {
    // The main-process global panic shortcut remains available as a fallback.
  }
}

function toggleCurrentMode() {
  if (state.busy || state.recordingHotkey) return;
  if (state.engine.running) void stopEngine();
  else void startEngine(state.view);
}

function bindRunControls() {
  $$('[data-run]').forEach((button) => {
    button.addEventListener('click', () => {
      const mode = button.dataset.run;
      if (state.engine.running) {
        if (state.engine.mode === mode) void stopEngine();
        else toast('أوقف العملية الحالية أولًا لبدء وضع آخر.', 'warn', 3200);
        return;
      }
      void startEngine(mode);
    });
  });

  $$('[data-panic]').forEach((button) => {
    button.addEventListener('click', () => {
      void panicStop();
    });
  });
}

/* ───────────── global hotkey capture & settings ───────────── */
const MODIFIER_CODES = new Set([
  'ControlLeft',
  'ControlRight',
  'AltLeft',
  'AltRight',
  'ShiftLeft',
  'ShiftRight',
  'MetaLeft',
  'MetaRight',
]);

const NAMED_KEYS = {
  Space: 'Space',
  Tab: 'Tab',
  Enter: 'Enter',
  Backspace: 'Backspace',
  Delete: 'Delete',
  Insert: 'Insert',
  ArrowUp: 'Up',
  ArrowDown: 'Down',
  ArrowLeft: 'Left',
  ArrowRight: 'Right',
  Home: 'Home',
  End: 'End',
  PageUp: 'PageUp',
  PageDown: 'PageDown',
};

function hotkeyModifiers(event) {
  const tokens = [];
  if (event.ctrlKey) tokens.push('Control');
  if (event.altKey) tokens.push('Alt');
  if (event.shiftKey) tokens.push('Shift');
  if (event.metaKey) tokens.push(isMac ? 'Command' : 'Super');
  return tokens;
}

function hotkeyMainKey(event) {
  if (/^Key[A-Z]$/.test(event.code)) return event.code.slice(3);
  if (/^Digit[0-9]$/.test(event.code)) return event.code.slice(5);
  if (/^F(?:[1-9]|1[0-9]|2[0-4])$/.test(event.key)) return event.key;
  return NAMED_KEYS[event.key] || null;
}

function hotkeyPreviewLabels(event) {
  const tokens = hotkeyModifiers(event);
  const key = hotkeyMainKey(event);
  if (key) tokens.push(key);
  return tokens.map(displayToken);
}

function setHotkeyFeedback(message, type = '') {
  const element = $('#hotkeyFeedback');
  if (!element) return;
  element.textContent = message;
  element.classList.toggle('is-ok', type === 'ok');
  element.classList.toggle('is-error', type === 'error');
}

function detachHotkeyCapture() {
  window.removeEventListener('keydown', handleHotkeyCapture, true);
  window.removeEventListener('keyup', handleHotkeyCaptureRelease, true);
}

function finishHotkeyCapture() {
  detachHotkeyCapture();
  state.recordingHotkey = null;
  state.recordingLabels = [];
}

function beginHotkeyRecording(which) {
  if (state.hotkeyBusy) return;
  if (state.recordingHotkey) {
    finishHotkeyCapture();
  } else {
    void api.suspendHotkeys();
  }

  state.recordingHotkey = which;
  state.recordingLabels = [];
  setHotkeyFeedback('اضغط التركيبة الجديدة الآن. استخدم Esc للإلغاء.', '');
  renderHotkeyFields();

  window.addEventListener('keydown', handleHotkeyCapture, true);
  window.addEventListener('keyup', handleHotkeyCaptureRelease, true);
}

function cancelHotkeyRecording({ announce = true, resume = true } = {}) {
  if (!state.recordingHotkey) return;
  finishHotkeyCapture();
  if (resume) void api.resumeHotkeys();
  if (announce) setHotkeyFeedback('تم إلغاء تغيير الاختصار.', '');
  renderHotkeyFields();
}

function handleHotkeyCaptureRelease(event) {
  if (!state.recordingHotkey) return;
  event.preventDefault();
  event.stopPropagation();
  state.recordingLabels = hotkeyPreviewLabels(event);
  renderHotkeyFields();
}

function handleHotkeyCapture(event) {
  if (!state.recordingHotkey) return;
  event.preventDefault();
  event.stopPropagation();
  if (event.repeat) return;

  if (event.key === 'Escape' && !event.ctrlKey && !event.altKey && !event.metaKey) {
    cancelHotkeyRecording();
    return;
  }

  state.recordingLabels = hotkeyPreviewLabels(event);
  renderHotkeyFields();

  if (MODIFIER_CODES.has(event.code)) return;

  const key = hotkeyMainKey(event);
  if (!key) {
    setHotkeyFeedback('هذا المفتاح غير مدعوم كاختصار. جرّب حرفًا أو رقمًا أو مفتاح F.', 'error');
    return;
  }

  const modifiers = hotkeyModifiers(event);
  const isFunctionKey = /^F(?:[1-9]|1[0-9]|2[0-4])$/.test(key);
  if (modifiers.length === 0 && !isFunctionKey) {
    setHotkeyFeedback('أضف Ctrl أو Alt أو Shift قبل المفتاح حتى لا يتعارض مع الكتابة.', 'warn');
    return;
  }

  const accelerator = [...modifiers, key].join('+');
  const which = state.recordingHotkey;
  const other = which === 'toggle' ? 'panic' : 'toggle';
  if (accelerator === state.hotkeys[other]) {
    setHotkeyFeedback('هذا الاختصار مستخدم للوظيفة الأخرى. اختر تركيبة مختلفة.', 'error');
    return;
  }

  void commitHotkey(which, accelerator);
}

async function commitHotkey(which, accelerator) {
  if (state.hotkeyBusy) return;
  state.hotkeyBusy = true;
  finishHotkeyCapture();
  renderHotkeyFields();
  setHotkeyFeedback('جارٍ تسجيل الاختصار…', '');

  const candidate = { ...state.hotkeys, [which]: accelerator };
  let result;
  try {
    result = await api.setHotkeys(candidate);
  } catch (error) {
    result = { ok: false, error: error?.message || 'تعذر تسجيل الاختصار.' };
  }

  await Promise.resolve(api.resumeHotkeys()).catch(() => {});

  if (result?.ok) {
    state.hotkeys = result.hotkeys || candidate;
    state.hotkeyStatus = result.status || state.hotkeyStatus;
    setHotkeyFeedback(
      `تم تسجيل ${which === 'toggle' ? 'اختصار التشغيل' : 'اختصار الإيقاف الطارئ'} بنجاح.`,
      'ok',
    );
    toast(`الاختصار الجديد: ${compactHotkey(accelerator)}`, 'ok', 2600);
  } else {
    state.hotkeyStatus = result?.status || state.hotkeyStatus;
    setHotkeyFeedback(result?.error || 'تعذر تسجيل الاختصار. جرّب تركيبة أخرى.', 'error');
    toast(result?.error || 'تعذر تسجيل الاختصار.', 'error', 4200);
  }

  state.hotkeyBusy = false;
  renderHotkeyFields();
}

function refreshHotkeyFeedback() {
  const failed = ['toggle', 'panic'].find((which) => state.hotkeyStatus?.[which]?.ok === false);
  if (!failed) {
    setHotkeyFeedback('انقر على الاختصار لتغييره، ثم اضغط التركيبة الجديدة.');
    return;
  }
  const label = failed === 'toggle' ? 'التشغيل' : 'الإيقاف الطارئ';
  setHotkeyFeedback(
    `تعذر تسجيل اختصار ${label} (${compactHotkey(state.hotkeys[failed])}). جرّب تركيبة أخرى.`,
    'error',
  );
}

function renderPreferences() {
  const tray = $('#prefTray');
  const autoLaunch = $('#prefAutoLaunch');
  if (tray) tray.checked = Boolean(state.prefs.tray);
  if (autoLaunch) autoLaunch.checked = Boolean(state.prefs.autoLaunch);
}

function openSettings() {
  if (state.settingsOpen) return;
  state.settingsOpen = true;
  const modal = $('#settingsModal');
  if (modal) modal.hidden = false;
  document.body.classList.add('is-settings-open');
  $('#btnSettings')?.setAttribute('aria-expanded', 'true');
  renderPreferences();
  renderHotkeyFields();
  refreshHotkeyFeedback();
  requestAnimationFrame(() => $('#btnCloseSettings')?.focus());
}

function closeSettings() {
  if (!state.settingsOpen) return;
  if (state.recordingHotkey) cancelHotkeyRecording({ announce: false });
  state.settingsOpen = false;
  const modal = $('#settingsModal');
  if (modal) modal.hidden = true;
  document.body.classList.remove('is-settings-open');
  $('#btnSettings')?.setAttribute('aria-expanded', 'false');
  $('#btnSettings')?.focus();
}

async function savePreference(key, input) {
  if (!input) return;
  const value = Boolean(input.checked);
  const previous = Boolean(state.prefs[key]);
  input.disabled = true;

  let result;
  try {
    result = await api.savePreferences({ [key]: value });
  } catch (error) {
    result = { ok: false, error: error?.message || 'تعذر حفظ التفضيل.' };
  }

  if (result?.ok) {
    state.prefs = { ...state.prefs, ...(result.preferences || {}) };
    input.checked = Boolean(state.prefs[key]);
    if (key === 'autoLaunch' && value) toast('سيبدأ نيزك مع النظام.', 'ok', 2600);
    if (key === 'tray' && !value) toast('عند إغلاق النافذة سيُطلب إنهاء التطبيق.', 'warn', 3400);
  } else {
    input.checked = previous;
    toast(result?.error || 'تعذر حفظ التفضيل.', 'error', 4200);
  }
  input.disabled = false;
}

function bindSettings() {
  $('#btnSettings')?.addEventListener('click', openSettings);
  $('#btnCloseSettings')?.addEventListener('click', closeSettings);
  $$('[data-close-settings]').forEach((element) => {
    element.addEventListener('click', closeSettings);
  });

  for (const which of ['toggle', 'panic']) {
    const field = document.getElementById(which === 'toggle' ? 'hotkeyToggle' : 'hotkeyPanic');
    field?.addEventListener('click', () => beginHotkeyRecording(which));
  }

  $('#prefTray')?.addEventListener('change', (event) => savePreference('tray', event.target));
  $('#prefAutoLaunch')?.addEventListener('change', (event) =>
    savePreference('autoLaunch', event.target),
  );

  $('#btnQuitApp')?.addEventListener('click', async (event) => {
    const button = event.currentTarget;
    button.disabled = true;
    const result = await api.quitApp().catch(() => ({ ok: false }));
    if (!result?.ok) button.disabled = false;
  });

  $('#btnAccessibility')?.addEventListener('click', async () => {
    const result = await api.openAccessibilitySettings().catch(() => ({ ok: false }));
    if (!result?.ok) toast('تعذر فتح إعدادات الخصوصية تلقائيًا.', 'error');
  });
}

/* ───────────── window chrome & navigation ───────────── */
function bindChrome() {
  $$('.nav-item').forEach((item) => {
    item.addEventListener('click', () => setView(item.dataset.nav));
  });

  $('#winClose')?.addEventListener('click', () => void api.close());
  $('#winMin')?.addEventListener('click', () => void api.minimize());
  $('#winMax')?.addEventListener('click', () => void api.maximize());

  $('.titlebar')?.addEventListener('dblclick', (event) => {
    if (event.target.closest('button, nav, .engine-pill')) return;
    void api.maximize();
  });

  window.addEventListener('resize', () => requestAnimationFrame(updateGlider));
  window.addEventListener('blur', () => {
    document.body.classList.add('is-blurred');
    if (state.recordingHotkey) cancelHotkeyRecording({ announce: false });
  });
  window.addEventListener('focus', () => document.body.classList.remove('is-blurred'));
  window.addEventListener('beforeunload', () => saveNow());

  document.addEventListener('keydown', (event) => {
    if (state.recordingHotkey) return;
    if (event.key === 'Escape' && state.settingsOpen) {
      event.preventDefault();
      closeSettings();
      return;
    }
    const command = isMac ? event.metaKey : event.ctrlKey;
    if (command && event.key === ',') {
      event.preventDefault();
      openSettings();
    }
  });

  window.addEventListener('keydown', (event) => {
    if (state.settingsOpen || state.engine.running) return;
    if (event.target.closest('input, textarea, [contenteditable="true"]')) return;
    if (event.key === 'ArrowLeft' || event.key === 'ArrowRight') {
      const order = ['single', 'multi', 'smart'];
      const index = order.indexOf(state.view);
      const next = event.key === 'ArrowLeft' ? (index + 1) % order.length : (index + 2) % order.length;
      setView(order[next]);
    }
  });
}

/* ───────────── boot ───────────── */
function demoForms() {
  const forms = structuredClone(DEFAULT_FORMS);
  forms.multi.points = [
    normalizePoint({ x: 820, y: 420, delay: 280 }),
    normalizePoint({ x: 1190, y: 530, delay: 620 }),
    normalizePoint({ x: 960, y: 720, delay: 180 }),
  ];
  forms.multi.repeat = 'count';
  forms.multi.count = 8;
  forms.single.speed = 20;
  forms.smart.interval = 140;
  return forms;
}

function applyBoot(boot) {
  state.boot = boot;
  const preferences = boot?.preferences;
  if (preferences && typeof preferences === 'object') {
    state.prefs = {
      tray: bool(preferences.tray, true),
      autoLaunch: bool(preferences.autoLaunch, false),
      trayHintShown: bool(preferences.trayHintShown, false),
    };
  }

  const hotkeys = boot?.hotkeys;
  if (hotkeys && typeof hotkeys === 'object') {
    state.hotkeys = {
      toggle: typeof hotkeys.toggle === 'string' && hotkeys.toggle ? hotkeys.toggle : 'F8',
      panic: typeof hotkeys.panic === 'string' && hotkeys.panic ? hotkeys.panic : 'F9',
    };
  }
  state.hotkeyStatus =
    boot?.hotkeyStatus && typeof boot.hotkeyStatus === 'object' ? boot.hotkeyStatus : {};

  state.forms = loadForms(boot?.ui);
  if (state.demo) state.forms = demoForms();

  if (boot?.engine && typeof boot.engine === 'object') {
    state.engine = { ...state.engine, ...boot.engine };
  }

  const savedView = boot?.ui?.tab;
  const requestedView = new URLSearchParams(window.location.search).get('view');
  const initialView = oneOf(requestedView || savedView, ['single', 'multi', 'smart'], 'single');

  const version = $('#appVersion');
  if (version) version.textContent = boot?.version || '1.0.0';

  hydrateSingle();
  renderMulti();
  updateSmartComputed();
  updateSingleComputed();
  renderPreferences();
  renderHotkeyFields();
  refreshHotkeyFeedback();
  bindRunControls();
  setView(initialView, { persist: false });

  const banner = $('#accessBanner');
  if (banner) banner.hidden = !(boot?.platform === 'darwin' && boot?.accessibility === false);

  requestAnimationFrame(updateGlider);
  if (document.fonts?.ready) {
    document.fonts.ready.then(() => requestAnimationFrame(updateGlider)).catch(() => {});
  }

  updateEngineUI();
}

async function init() {
  normalizeNumericInputs();
  bindSingle();
  bindMulti();
  bindSmart();
  bindSteppers();
  bindChrome();
  bindSettings();

  api.onEngineState(handleEngineState);
  api.onHotkeyToggle(() => toggleCurrentMode());
  api.onHotkeysStatus((status) => {
    if (status && typeof status === 'object') {
      state.hotkeyStatus = status;
      for (const which of ['toggle', 'panic']) {
        if (status[which]?.ok && typeof status[which].accelerator === 'string') {
          state.hotkeys[which] = status[which].accelerator;
        }
      }
      renderHotkeyFields();
    }
  });
  api.onWindowMaximized((maximized) => {
    document.body.classList.toggle('is-maximized', Boolean(maximized));
  });

  try {
    const boot = await api.bootstrap();
    if (!boot) {
      toast('تعذر تحميل إعدادات التطبيق.', 'error', 5000);
      return;
    }
    applyBoot(boot);
  } catch (error) {
    toast(error?.message || 'تعذر تشغيل واجهة نيزك.', 'error', 6000);
  }
}

void init();
