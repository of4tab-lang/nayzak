'use strict';

const APP_ID = 'com.nayzak.app';
const APP_NAME = 'NAYZAK';
const APP_NAME_AR = 'نيزك';

module.exports = { APP_ID, APP_NAME, APP_NAME_AR };
