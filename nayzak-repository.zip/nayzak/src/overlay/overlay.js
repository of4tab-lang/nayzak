'use strict';

const params = new URLSearchParams(window.location.search);
const index = Number(params.get('index') || 1);
const total = Number(params.get('total') || 1);

const root = document.documentElement;
const reticle = document.getElementById('reticle');
const coord = document.getElementById('coord');
const lineX = document.getElementById('lineX');
const lineY = document.getElementById('lineY');
const ripple = document.getElementById('ripple');
const displayChip = document.getElementById('displayChip');

let latest = null;
let finished = false;

if (total > 1) {
  displayChip.textContent = `الشاشة ${index} من ${total}`;
} else {
  displayChip.textContent = 'NAYZAK · POINT PICKER';
}

function setPosition(x, y) {
  root.style.setProperty('--x', `${x}px`);
  root.style.setProperty('--y', `${y}px`);
  latest = { x, y };
}

function updateReticle(event) {
  if (finished) return;
  setPosition(event.clientX, event.clientY);
  reticle.hidden = false;
  document.body.classList.add('has-pointer');

  const screenX = Math.round(event.screenX);
  const screenY = Math.round(event.screenY);
  coord.textContent = `${screenX}, ${screenY}`;

  reticle.classList.toggle('flip-x', event.clientX > window.innerWidth - 180);
  reticle.classList.toggle('flip-y', event.clientY > window.innerHeight - 120);
}

function finish(x, y) {
  if (finished) return;
  finished = true;
  setPosition(x, y);
  ripple.classList.add('pop');
  document.body.classList.add('captured');
  setTimeout(() => {
    window.overlay?.submit(Math.round(x), Math.round(y));
  }, 170);
}

function cancel() {
  if (finished) return;
  finished = true;
  document.body.classList.add('captured');
  window.overlay?.cancel();
}

window.addEventListener('pointermove', updateReticle, { passive: true });

window.addEventListener('pointerdown', (event) => {
  if (finished) return;
  if (event.button === 2) {
    event.preventDefault();
    cancel();
    return;
  }
  if (event.button !== 0) return;
  event.preventDefault();
  finish(event.screenX, event.screenY);
});

window.addEventListener('contextmenu', (event) => {
  event.preventDefault();
  if (!finished) cancel();
});

window.addEventListener('keydown', (event) => {
  if (event.key === 'Escape') {
    event.preventDefault();
    cancel();
  }
});

window.addEventListener('blur', () => {
  document.body.classList.remove('has-pointer');
});

window.addEventListener('focus', () => {
  if (latest && !finished) document.body.classList.add('has-pointer');
});

// Warm up the crosshair at the center of this display until the pointer moves.
setPosition(window.innerWidth / 2, window.innerHeight / 2);
