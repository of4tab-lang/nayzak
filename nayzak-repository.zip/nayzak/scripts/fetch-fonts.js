'use strict';

/* Downloads the Tajawal / Manrope web fonts used by the UI (needs internet once). */
const fs = require('node:fs');
const path = require('node:path');
const https = require('node:https');

const dir = path.resolve(__dirname, '..', 'src', 'renderer', 'assets', 'fonts');
const base = 'https://fonts.gstatic.com/s/';
const items = {
  'tajawal-400-ar.woff2': 'tajawal/v12/Iura6YBj_oCad4k1nzSBC45I.woff2',
  'tajawal-400-latin.woff2': 'tajawal/v12/Iura6YBj_oCad4k1nzGBCw.woff2',
  'tajawal-500-ar.woff2': 'tajawal/v12/Iurf6YBj_oCad4k1l8KiHrRpiYlJ.woff2',
  'tajawal-500-latin.woff2': 'tajawal/v12/Iurf6YBj_oCad4k1l8KiHrFpiQ.woff2',
  'tajawal-700-ar.woff2': 'tajawal/v12/Iurf6YBj_oCad4k1l4qkHrRpiYlJ.woff2',
  'tajawal-700-latin.woff2': 'tajawal/v12/Iurf6YBj_oCad4k1l4qkHrFpiQ.woff2',
  'tajawal-800-ar.woff2': 'tajawal/v12/Iurf6YBj_oCad4k1l5anHrRpiYlJ.woff2',
  'tajawal-800-latin.woff2': 'tajawal/v12/Iurf6YBj_oCad4k1l5anHrFpiQ.woff2',
  'manrope-latin.woff2': 'manrope/v20/xn7gYHE41ni1AdIRggexSg.woff2',
};

function get(url) {
  return new Promise((resolve, reject) => {
    https
      .get(url, { headers: { 'User-Agent': 'Mozilla/5.0 Chrome/124.0' } }, (res) => {
        if (res.statusCode !== 200) return reject(new Error(`${res.statusCode} ${url}`));
        const chunks = [];
        res.on('data', (c) => chunks.push(c));
        res.on('end', () => resolve(Buffer.concat(chunks)));
      })
      .on('error', reject);
  });
}

(async () => {
  fs.mkdirSync(dir, { recursive: true });
  for (const [name, rel] of Object.entries(items)) {
    const file = path.join(dir, name);
    if (fs.existsSync(file) && fs.statSync(file).size > 1000) continue;
    fs.writeFileSync(file, await get(base + rel));
    console.log('[NAYZAK] font', name);
  }
  console.log('[NAYZAK] Fonts ready.');
})().catch((e) => {
  console.error('[NAYZAK] Font download failed:', e.message);
  process.exit(1);
});
