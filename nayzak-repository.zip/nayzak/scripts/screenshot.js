'use strict';

const path = require('node:path');
const fs = require('node:fs');
const { spawn } = require('node:child_process');

const electron = require('electron');
const root = path.resolve(__dirname, '..');
const outputDir = path.join(root, 'screenshots');
const args = process.argv.slice(2);

const views = ['single', 'multi', 'smart'];
const requested = args.find((argument) => argument.startsWith('--view='))?.split('=')[1];
const customOut = args.find((argument) => argument.startsWith('--out='))?.slice(6);
const all = args.includes('--all') || requested === 'all';
const demo = !args.includes('--real');
const selectedViews = all ? views : [requested || 'single'];

fs.mkdirSync(outputDir, { recursive: true });

function capture(view, outputPath) {
  return new Promise((resolve, reject) => {
    const env = {
      ...process.env,
      NAYZAK_SHOT: outputPath,
      NAYZAK_SHOT_VIEW: view,
    };
    if (demo) env.NAYZAK_SHOT_DEMO = '1';
    else delete env.NAYZAK_SHOT_DEMO;

    const child = spawn(electron, ['.'], {
      cwd: root,
      env,
      stdio: 'inherit',
      windowsHide: false,
    });

    child.once('error', reject);
    child.once('exit', (code) => {
      if (code === 0) resolve();
      else reject(new Error(`Electron exited with code ${code}`));
    });
  });
}

(async () => {
  for (const view of selectedViews) {
    if (!views.includes(view)) {
      throw new Error(`Unknown view "${view}". Use one of: ${views.join(', ')}, all`);
    }
    const output = all || !customOut
      ? path.join(outputDir, `nayzak-${view}${demo ? '-demo' : ''}.png`)
      : path.resolve(customOut);
    console.log(`[screenshots] Capturing ${view} → ${output}`);
    await capture(view, output);
  }
  console.log('[screenshots] Done.');
})().catch((error) => {
  console.error('[screenshots] Failed:', error);
  process.exitCode = 1;
});
