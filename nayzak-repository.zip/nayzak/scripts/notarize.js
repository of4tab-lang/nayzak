'use strict';

const path = require('node:path');

/**
 * Notarize only when a Developer ID signature and Apple credentials are both
 * available. Local unsigned builds and Windows builds intentionally skip this.
 */
exports.default = async function notarizeMac(context) {
  if (context.electronPlatformName !== 'darwin') return;

  const appleId = process.env.APPLE_ID;
  const appleIdPassword =
    process.env.APPLE_APP_SPECIFIC_PASSWORD || process.env.APPLE_ID_PASSWORD;
  const teamId = process.env.APPLE_TEAM_ID;

  if (!appleId || !appleIdPassword || !teamId) {
    console.log('[notarize] Skipping notarization: Apple credentials are not configured.');
    return;
  }

  const { notarize } = require('@electron/notarize');
  const appPath = path.join(
    context.appOutDir,
    `${context.packager.appInfo.productFilename}.app`,
  );

  console.log(`[notarize] Submitting ${appPath} to Apple notary service…`);
  await notarize({
    appPath,
    appleId,
    appleIdPassword,
    teamId,
  });
  console.log('[notarize] Notarization complete.');
};
