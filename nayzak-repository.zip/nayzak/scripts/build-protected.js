'use strict';

/*
 * Builds a release package whose JavaScript has been transformed before it
 * enters app.asar. The original readable sources are restored immediately
 * after electron-builder exits.
 *
 * This is deterrence, not cryptographic protection: any Electron application
 * can eventually be inspected on the machine that runs it. It does, however,
 * keep the shipped installer free of plainly readable application code.
 */

const fs = require('node:fs');
const os = require('node:os');
const path = require('node:path');
const { spawnSync } = require('node:child_process');
const JavaScriptObfuscator = require('javascript-obfuscator');

const root = path.resolve(__dirname, '..');
const args = process.argv.slice(2);
const isMac = args.includes('--mac');
const obfuscationDisabled = process.env.NAYZAK_SKIP_OBFUSCATION === '1';

function sourceFiles(directory) {
  return fs
    .readdirSync(path.join(root, directory), { withFileTypes: true })
    .flatMap((entry) => {
      const relative = path.posix.join(directory, entry.name);
      if (entry.isDirectory()) return sourceFiles(relative);
      return entry.isFile() && entry.name.endsWith('.js') ? [relative] : [];
    });
}

const files = ['src/main', 'src/preload', 'src/renderer', 'src/overlay', 'src/shared']
  .flatMap((directory) => sourceFiles(directory))
  .sort();

const backupRoot = fs.mkdtempSync(path.join(os.tmpdir(), 'nayzak-source-'));

function copyToBackup(relative) {
  const target = path.join(backupRoot, relative);
  fs.mkdirSync(path.dirname(target), { recursive: true });
  fs.copyFileSync(path.join(root, relative), target);
}

function restore() {
  for (const relative of files) {
    const backup = path.join(backupRoot, relative);
    if (fs.existsSync(backup)) {
      fs.copyFileSync(backup, path.join(root, relative));
    }
  }
}

function obfuscate(relative) {
  const source = fs.readFileSync(path.join(root, relative), 'utf8');
  const target =
    relative.startsWith('src/renderer/') || relative.startsWith('src/overlay/')
      ? 'browser'
      : 'node';
  const result = JavaScriptObfuscator.obfuscate(source, {
    compact: true,
    controlFlowFlattening: false,
    deadCodeInjection: false,
    debugProtection: false,
    disableConsoleOutput: false,
    identifierNamesGenerator: 'hexadecimal',
    log: false,
    numbersToExpressions: false,
    renameGlobals: false,
    selfDefending: false,
    simplify: true,
    splitStrings: false,
    stringArray: true,
    stringArrayCallsTransform: false,
    stringArrayEncoding: ['base64'],
    stringArrayIndexShift: true,
    stringArrayRotate: true,
    stringArrayShuffle: true,
    stringArrayThreshold: 0.72,
    transformObjectKeys: false,
    unicodeEscapeSequence: false,
    seed: 20261023,
    target,
  });
  fs.writeFileSync(path.join(root, relative), result.getObfuscatedCode(), 'utf8');
}

function runBuilder() {
  const cli = require.resolve('electron-builder/out/cli/cli.js');
  const builderArgs = isMac ? ['--mac', '--universal'] : ['--win', process.env.NAYZAK_TARGET || 'nsis'];
  const result = spawnSync(process.execPath, [cli, ...builderArgs], {
    cwd: root,
    stdio: 'inherit',
    env: process.env,
  });
  if (result.error) throw result.error;
  return result.status ?? 1;
}

let exitCode = 1;
try {
  if (!obfuscationDisabled) {
    console.log(`[protected-build] Backing up ${files.length} source files to ${backupRoot}`);
    for (const relative of files) copyToBackup(relative);
    console.log('[protected-build] Obfuscating application JavaScript…');
    for (const relative of files) {
      obfuscate(relative);
      console.log(`  · ${relative}`);
    }
  } else {
    console.log('[protected-build] Obfuscation skipped by NAYZAK_SKIP_OBFUSCATION.');
  }

  exitCode = runBuilder();
} catch (error) {
  console.error(error.stack || error);
  exitCode = 1;
} finally {
  if (!obfuscationDisabled) {
    try {
      restore();
      fs.rmSync(backupRoot, { recursive: true, force: true });
      console.log('[protected-build] Readable sources restored.');
    } catch (error) {
      console.error(`[protected-build] Could not restore sources. Backup: ${backupRoot}`);
      console.error(error.stack || error);
      exitCode = 1;
    }
  }
}

process.exitCode = exitCode;
