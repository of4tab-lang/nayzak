'use strict';

const fs = require('node:fs');
const path = require('node:path');
const sharp = require('sharp');

const root = path.join(__dirname, '..');
const buildDir = path.join(root, 'build');
const assetsDir = path.join(root, 'assets');
const iconSvg = fs.readFileSync(path.join(buildDir, 'icon.svg'));
const traySvg = fs.readFileSync(path.join(buildDir, 'tray-template.svg'));

fs.mkdirSync(assetsDir, { recursive: true });

async function pngFrom(buffer, size, file) {
  await sharp(buffer, { density: 384 }).resize(size, size).png().toFile(file);
}

function pngBuffer(buffer, size) {
  return sharp(buffer, { density: 384 }).resize(size, size).png().toBuffer();
}

function writeIco(file, entries) {
  const count = entries.length;
  const header = Buffer.alloc(6);
  header.writeUInt16LE(0, 0);
  header.writeUInt16LE(1, 2);
  header.writeUInt16LE(count, 4);

  const directory = Buffer.alloc(16 * count);
  let offset = 6 + directory.length;
  entries.forEach(([size, data], index) => {
    const entry = 16 * index;
    directory.writeUInt8(size >= 256 ? 0 : size, entry);
    directory.writeUInt8(size >= 256 ? 0 : size, entry + 1);
    directory.writeUInt8(0, entry + 2);
    directory.writeUInt8(0, entry + 3);
    directory.writeUInt16LE(1, entry + 4);
    directory.writeUInt16LE(32, entry + 6);
    directory.writeUInt32LE(data.length, entry + 8);
    directory.writeUInt32LE(offset, entry + 12);
    offset += data.length;
  });

  fs.writeFileSync(file, Buffer.concat([header, directory, ...entries.map(([, data]) => data)]));
}

function writeIcns(file, pngs) {
  const chunks = [];
  for (const [type, data] of pngs) {
    const header = Buffer.alloc(8);
    header.write(type, 0, 4, 'ascii');
    header.writeUInt32BE(data.length + 8, 4);
    chunks.push(header, data);
  }

  const body = Buffer.concat(chunks);
  const header = Buffer.alloc(8);
  header.write('icns', 0, 4, 'ascii');
  header.writeUInt32BE(body.length + 8, 4);
  fs.writeFileSync(file, Buffer.concat([header, body]));
}

async function main() {
  const masters = {
    16: await pngBuffer(iconSvg, 16),
    24: await pngBuffer(iconSvg, 24),
    32: await pngBuffer(iconSvg, 32),
    48: await pngBuffer(iconSvg, 48),
    64: await pngBuffer(iconSvg, 64),
    128: await pngBuffer(iconSvg, 128),
    256: await pngBuffer(iconSvg, 256),
    512: await pngBuffer(iconSvg, 512),
    1024: await pngBuffer(iconSvg, 1024),
  };

  fs.writeFileSync(path.join(buildDir, 'icon.png'), masters[1024]);
  await pngFrom(iconSvg, 512, path.join(buildDir, 'icon-512.png'));

  writeIco(
    path.join(buildDir, 'icon.ico'),
    [16, 24, 32, 48, 64, 128, 256].map((size) => [size, masters[size]]),
  );

  writeIcns(path.join(buildDir, 'icon.icns'), [
    ['icp4', masters[16]],
    ['icp5', masters[32]],
    ['icp6', masters[64]],
    ['ic07', masters[128]],
    ['ic08', masters[256]],
    ['ic09', masters[512]],
    ['ic10', masters[1024]],
    ['ic11', await pngBuffer(iconSvg, 32)],
    ['ic12', await pngBuffer(iconSvg, 64)],
    ['ic13', masters[256]],
    ['ic14', masters[512]],
  ]);

  fs.writeFileSync(
    path.join(assetsDir, 'tray.png'),
    await pngBuffer(iconSvg, 32),
  );
  fs.writeFileSync(
    path.join(assetsDir, 'tray@2x.png'),
    await pngBuffer(iconSvg, 64),
  );

  const template22 = await pngBuffer(traySvg, 22);
  const template44 = await pngBuffer(traySvg, 44);
  fs.writeFileSync(path.join(assetsDir, 'trayTemplate.png'), template22);
  fs.writeFileSync(path.join(assetsDir, 'trayTemplate@2x.png'), template44);

  const logo = await pngBuffer(traySvg, 128);
  fs.writeFileSync(path.join(assetsDir, 'mark.png'), logo);

  console.log('[NAYZAK] Icons generated: build/icon.ico, build/icon.icns, build/icon.png, assets/tray*.png');
}

main().catch((error) => {
  console.error(error);
  process.exit(1);
});
