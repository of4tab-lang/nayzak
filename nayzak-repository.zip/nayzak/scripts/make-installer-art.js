'use strict';

/* Builds build/installerSidebar.bmp (164x314) and build/installerHeader.bmp (150x57)
 * for the NSIS wizard. Requires build/icon-512.png (run `npm run icons` first). */
const fs = require('node:fs');
const path = require('node:path');
const sharp = require('sharp');

const buildDir = path.resolve(__dirname, '..', 'build');

function bmp24(width, height, rgb) {
  const rowSize = Math.ceil((width * 3) / 4) * 4;
  const out = Buffer.alloc(54 + rowSize * height);
  out.write('BM', 0);
  out.writeUInt32LE(out.length, 2);
  out.writeUInt32LE(54, 10);
  out.writeUInt32LE(40, 14);
  out.writeInt32LE(width, 18);
  out.writeInt32LE(height, 22);
  out.writeUInt16LE(1, 26);
  out.writeUInt16LE(24, 28);
  out.writeUInt32LE(rowSize * height, 34);
  for (let y = 0; y < height; y++) {
    const src = (height - 1 - y) * width * 3;
    const dst = 54 + y * rowSize;
    for (let x = 0; x < width; x++) {
      out[dst + x * 3] = rgb[src + x * 3 + 2];
      out[dst + x * 3 + 1] = rgb[src + x * 3 + 1];
      out[dst + x * 3 + 2] = rgb[src + x * 3];
    }
  }
  return out;
}

async function make(file, w, h, logoSize, logoLeft, logoTop, glowSvg) {
  const bg = `<svg xmlns="http://www.w3.org/2000/svg" width="${w}" height="${h}">
    <defs><linearGradient id="g" x1="0" y1="0" x2="0" y2="1">
      <stop offset="0" stop-color="#070910"/><stop offset="1" stop-color="#0f1522"/></linearGradient>
      <radialGradient id="a"><stop offset="0" stop-color="#5ed8ff" stop-opacity=".22"/><stop offset="1" stop-color="#5ed8ff" stop-opacity="0"/></radialGradient>
      <radialGradient id="b"><stop offset="0" stop-color="#9b78ff" stop-opacity=".2"/><stop offset="1" stop-color="#9b78ff" stop-opacity="0"/></radialGradient></defs>
    <rect width="${w}" height="${h}" fill="url(#g)"/>${glowSvg}</svg>`;
  const logo = await sharp(path.join(buildDir, 'icon-512.png')).resize(logoSize, logoSize).png().toBuffer();
  const raw = await sharp(Buffer.from(bg))
    .composite([{ input: logo, left: logoLeft, top: logoTop }])
    .removeAlpha()
    .raw()
    .toBuffer();
  fs.writeFileSync(file, bmp24(w, h, raw));
  console.log('[NAYZAK] wrote', path.relative(process.cwd(), file));
}

(async () => {
  await make(path.join(buildDir, 'installerSidebar.bmp'), 164, 314, 96, 34, 110,
    '<circle cx="40" cy="252" r="84" fill="url(#a)"/><circle cx="140" cy="64" r="84" fill="url(#b)"/>');
  await make(path.join(buildDir, 'installerHeader.bmp'), 150, 57, 40, 100, 8,
    '<circle cx="20" cy="50" r="50" fill="url(#a)"/>');
})().catch((e) => { console.error(e); process.exit(1); });
