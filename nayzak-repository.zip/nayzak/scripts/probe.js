const { app, screen } = require('electron');

app.whenReady().then(async () => {
  const out = {
    electron: process.versions.electron,
    platform: process.platform,
    isPackaged: app.isPackaged,
  };
  try {
    const { mouse } = require('@nut-tree-fork/nut-js');
    out.nutLoaded = true;
    out.mouseConfig = { ...mouse.config };
    out.nutPosition = await mouse.getPosition();
    out.dipPosition = screen.getCursorScreenPoint();
    out.displays = screen.getAllDisplays().map(d => ({
      id: d.id,
      bounds: d.bounds,
      workArea: d.workArea,
      scaleFactor: d.scaleFactor,
    }));
    out.hasDipToScreen = typeof screen.dipToScreenPoint === 'function';
    if (out.hasDipToScreen) {
      out.dipToScreen = screen.dipToScreenPoint(out.dipPosition);
    }
  } catch (err) {
    out.error = { message: err.message, stack: err.stack };
  }
  console.log('PROBE_RESULT ' + JSON.stringify(out));
  app.quit();
});
